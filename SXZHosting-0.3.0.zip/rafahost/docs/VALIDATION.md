# Validación de la actualización 0.3.0

Ejecutado en esta actualización:

- 17 pruebas del backend: aprobadas. El backend conserva las mismas APIs de 0.2.
- 14 archivos Dart pasan el parser sintáctico Tree-sitter. No sustituye el analizador de tipos de Flutter.
- Configuración de plataformas ejecutada sobre archivos de prueba: Bundle ID, permiso de Fotos, ID AdMob y plataforma CocoaPods 15.0 correctos.
- YAML Codemagic, sintaxis de todos sus scripts Bash y código Python incrustado comprobados.
- Guía visual SVG renderizada a PNG e inspeccionada; usa datos de ejemplo, no una captura Flutter.

Pendiente en Codemagic:

- `flutter analyze`, las pruebas Dart/Flutter (incluidas 6 de propiedades y 4 de interfaz) y el build firmado.
- Las pruebas de interfaz cubren acceso/registro a 320 y 390 px, controles y búsqueda de archivos en una pantalla pequeña, y tienda en temas claro y oscuro.
- Las pruebas de propiedades cubren conservación de comentarios y opciones ajenas, CRLF, valores Unicode, intentos de introducir nuevas líneas, conflictos de escritura y archivos complejos.

No se ejecuta el SDK Flutter localmente: su preparación fue rechazada previamente por la revisión automática del entorno. La verificación nativa queda en el workflow macOS autorizado de Codemagic.

Faltan pruebas de uso real en iPhone y conexión a un nodo Pterodactyl/Wings real. La VPS actual está en modo demo; los comandos, métricas y servidores son simulados. No se ha iniciado ni publicado un nuevo build desde esta sesión.
