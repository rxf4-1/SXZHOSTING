"""Run after bootstrap. Uses test AdMob app IDs unless explicitly supplied."""
import os
import plistlib
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]/'app'
plist=root/'ios/Runner/Info.plist'
with plist.open('rb') as f: data=plistlib.load(f)
data['CFBundleDisplayName']='SXZ Hosting'
data['NSPhotoLibraryUsageDescription']='Permite seleccionar fotos para subirlas como archivos al servidor que administras.'
data['GADApplicationIdentifier']=os.getenv('ADMOB_IOS_APP_ID','ca-app-pub-9419517058946613~9936383467')
# No blanket ATS bypass; use a public HTTPS API on a physical device.
with plist.open('wb') as f: plistlib.dump(data,f)
project=root/'ios/Runner.xcodeproj/project.pbxproj'
project.write_text(project.read_text().replace('dev.rafa.rafahost','com.rafastudio.sphost'))
podfile=root/'ios/Podfile'
if podfile.exists():
    import re
    text=podfile.read_text()
    pattern=r"(?m)^[ \t]*#?[ \t]*platform[ \t]+:ios[^\n]*"
    text=re.sub(pattern,"platform :ios, '15.0'",text) if re.search(pattern,text) else "platform :ios, '15.0'\n"+text
    podfile.write_text(text)
android='{http://schemas.android.com/apk/res/android}'
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
manifest=root/'android/app/src/main/AndroidManifest.xml'
tree=ET.parse(manifest)
element=tree.getroot()
if not any(x.get(android+'name')=='android.permission.INTERNET' for x in element.findall('uses-permission')):
    ET.SubElement(element,'uses-permission',{android+'name':'android.permission.INTERNET'})
app=element.find('application')
app.set(android+'label','SXZ Hosting')
for item in list(app.findall('meta-data')):
    if item.get(android+'name')=='com.google.android.gms.ads.APPLICATION_ID': app.remove(item)
ET.SubElement(app,'meta-data',{android+'name':'com.google.android.gms.ads.APPLICATION_ID',android+'value':os.getenv('ADMOB_ANDROID_APP_ID','ca-app-pub-3940256099942544~3347511713')})
tree.write(manifest,encoding='utf-8',xml_declaration=True)
print('Plataformas configuradas. App ID iOS configurado; Android mantiene un App ID de prueba.')
