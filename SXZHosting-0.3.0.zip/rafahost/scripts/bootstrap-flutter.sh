#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v flutter >/dev/null || { echo 'Instala Flutter estable y vuelve a ejecutar este script.'; exit 1; }
flutter config --no-enable-swift-package-manager
platform_tmp="$(mktemp -d)"
trap 'rm -rf "$platform_tmp"' EXIT
flutter create --project-name rafahost --org dev.rafa --platforms ios,android,web "$platform_tmp/rafahost"
for platform in ios android web; do
  if [ ! -d "$project_dir/app/$platform" ]; then
    cp -R "$platform_tmp/rafahost/$platform" "$project_dir/app/$platform"
  fi
done
python3 "$project_dir/scripts/configure-platforms.py"
cd "$project_dir/app"
flutter pub get
dart format lib test
flutter analyze
flutter test
