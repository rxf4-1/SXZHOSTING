import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'data/api.dart';
import 'data/repository.dart';
import 'ui/hosting_model.dart';
import 'ui/screens.dart';
import 'ui/design.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  const configured = String.fromEnvironment('API_BASE_URL');
  final base = configured.isNotEmpty ? configured : (kIsWeb ? Uri.base.origin : 'http://localhost:8000');
  final uri = Uri.parse(base);
  if (kReleaseMode && uri.scheme != 'https') {
    runApp(const MaterialApp(home: Scaffold(body: Center(child: Text('Configura API_BASE_URL con una dirección HTTPS.')))));
    return;
  }
  runApp(HostingApp(model: HostingModel(HostingRepository(Api(base)))));
}

class HostingApp extends StatefulWidget {
  const HostingApp({super.key, required this.model});
  final HostingModel model;
  @override State<HostingApp> createState() => _HostingAppState();
}
class _HostingAppState extends State<HostingApp> {
  @override void initState() { super.initState(); widget.model.initialize(); }
  @override void dispose() { widget.model.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ListenableBuilder(
    listenable: widget.model,
    builder: (context, _) => MaterialApp(
      title: 'SXZ Hosting', debugShowCheckedModeBanner: false,
      theme: hostingTheme(Brightness.light),
      darkTheme: hostingTheme(Brightness.dark),
      themeMode: widget.model.darkMode ? ThemeMode.dark : ThemeMode.light,
      home: Shell(model: widget.model),
    ),
  );
}
