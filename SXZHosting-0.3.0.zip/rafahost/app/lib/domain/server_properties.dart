// Edits the small, explicitly supported subset of Java properties used by the UI.
// Unknown keys, comments and order are preserved. Complex continuations go to the editor.
class ServerProperties {
  ServerProperties(this.source) {
    if (source.contains('\u0000')) {
      throw const FormatException('El archivo no es texto.');
    }
    for (final line in source.split('\n')) {
      final tail = RegExp(r'\\+$').firstMatch(line.replaceAll('\r', ''));
      if (tail != null && tail.group(0)!.length.isOdd) {
        throw const FormatException('Este archivo usa líneas continuadas. Edítalo desde Archivos para conservar su formato.');
      }
    }
  }
  final String source;
  static final _entry = RegExp(r'^\s*([A-Za-z0-9._-]+)(?:\s*[=:]\s*|\s+)(.*)$');
  static RegExpMatch? entry(String line) {
    if (line.trimLeft().startsWith('#') || line.trimLeft().startsWith('!')) { return null; }
    return _entry.firstMatch(line.replaceAll('\r', ''));
  }
  Map<String, String> get values {
    final result = <String, String>{};
    for (final line in source.split('\n')) {
      final match = entry(line);
      if (match != null) { result[match.group(1)!] = decode(match.group(2)!); }
    }
    return result;
  }
  static String decode(String value) => value.replaceAllMapped(RegExp(r'\\u([0-9a-fA-F]{4})|\\(.)'), (m) {
    if (m.group(1) != null) { return String.fromCharCode(int.parse(m.group(1)!, radix: 16)); }
    return switch (m.group(2)) { 'n' => '\n', 'r' => '\r', 't' => '\t', 'f' => '\f', final v => v! };
  });
  static String encode(String value) {
    final out = StringBuffer();
    for (final code in value.codeUnits) {
      if (code == 92) { out.write(r'\\'); }
      else if (code < 32 || code > 126) { out.write('\\u${code.toRadixString(16).padLeft(4, '0')}'); }
      else { out.writeCharCode(code); }
    }
    return out.toString();
  }
  String merge(Map<String, String> updates, {required Map<String, String> original}) {
    final current = values;
    for (final key in updates.keys) {
      if (current[key] != original[key] && current[key] != updates[key]) {
        throw FormatException('La opción $key cambió desde otro panel. Vuelve a cargar antes de guardar.');
      }
    }
    final seen = <String>{};
    final lines = source.replaceAll('\r\n', '\n').split('\n').map((line) {
      final match = entry(line);
      final key = match?.group(1);
      if (key != null && updates.containsKey(key)) {
        seen.add(key); return '$key=${encode(updates[key]!)}';
      }
      return line;
    }).toList();
    if (lines.isNotEmpty && lines.last.isEmpty) { lines.removeLast(); }
    for (final key in updates.keys.where((k) => !seen.contains(k))) {
      lines.add('$key=${encode(updates[key]!)}');
    }
    final newline = source.contains('\r\n') ? '\r\n' : '\n';
    return '${lines.join(newline)}$newline';
  }
}
