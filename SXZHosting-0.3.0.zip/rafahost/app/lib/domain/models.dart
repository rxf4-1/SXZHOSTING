class GameServer {
  const GameServer({required this.id, required this.name, required this.status, required this.expires, this.memory = 1024, this.disk = 2048, this.cpu = 100});
  final String id, name, status;
  final DateTime expires;
  final int memory, disk, cpu;
  factory GameServer.fromJson(Map<String, dynamic> j) => GameServer(
    id: j['id'] as String, name: j['name'] as String, status: j['status'] as String,
    memory: (j['memory'] as num?)?.toInt() ?? 1024, disk: (j['disk'] as num?)?.toInt() ?? 2048, cpu: (j['cpu'] as num?)?.toInt() ?? 100,
    expires: DateTime.fromMillisecondsSinceEpoch(((j['expires'] as num) * 1000).round()),
  );
  Duration get remaining => expires.difference(DateTime.now());
  bool get expired => remaining.isNegative;
  String get timeLabel {
    if (expired) return 'Tiempo agotado';
    return '${remaining.inHours} h ${remaining.inMinutes.remainder(60)} min';
  }
}

class ServerFile {
  const ServerFile({required this.name, required this.path, required this.isDir, required this.size});
  final String name, path;
  final bool isDir;
  final int size;
  factory ServerFile.fromJson(Map<String, dynamic> j) => ServerFile(name: j['name'] as String, path: j['path'] as String, isDir: j['is_dir'] as bool, size: (j['size'] as num).toInt());
}
