import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../domain/models.dart';
import 'design.dart';
import 'hosting_model.dart';
import 'wallet_view.dart';
import 'world_settings.dart';

class Shell extends StatefulWidget {
  const Shell({super.key, required this.model});
  final HostingModel model;
  @override State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int section = 0;
  @override Widget build(BuildContext context) {
    final m = widget.model;
    if (!m.initialized) {
      return Scaffold(body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.view_in_ar_outlined, size: 46, color: brandBlue), const SizedBox(height: 16),
        const Text('SXZ', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)), const SizedBox(height: 24),
        const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
      ])));
    }
    if (!m.signedIn) { return LoginView(model: m); }
    return Scaffold(
      appBar: AppBar(
        leading: m.selected != null && section == 0 ? IconButton(tooltip: 'Mis servidores', onPressed: m.busy ? null : m.back, icon: const Icon(Icons.arrow_back)) : null,
        title: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.view_in_ar_outlined, color: brandBlue), SizedBox(width: 9), Text('SXZ', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, letterSpacing: -.7))]),
        actions: [if (m.demo) const Padding(padding: EdgeInsets.only(right: 8), child: StatusPill('Pruebas')), IconButton(tooltip: 'Actualizar', onPressed: m.busy ? null : m.refresh, icon: const Icon(Icons.refresh_rounded)), const SizedBox(width: 8)],
      ),
      body: SafeArea(child: Column(children: [
        if (m.busy) const LinearProgressIndicator(minHeight: 2),
        if (m.message.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 0), child: Panel(padding: const EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.info_outline, size: 19), const SizedBox(width: 10), Expanded(child: Text(m.message))]))),
        Expanded(child: section == 1 ? WalletContent(model: m) : section == 2 ? AccountView(model: m) : m.selected == null ? Dashboard(model: m) : DetailView(key: ValueKey(m.selected!.id), model: m)),
      ])),
      bottomNavigationBar: NavigationBar(selectedIndex: section, onDestinationSelected: (v) => setState(() => section = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.dns_outlined), selectedIcon: Icon(Icons.dns_rounded), label: 'Servidores'),
        NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Monedas'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Mi cuenta'),
      ]),
    );
  }
}

class LoginView extends StatefulWidget {
  const LoginView({super.key, required this.model});
  final HostingModel model;
  @override State<LoginView> createState() => _LoginViewState();
}
class _LoginViewState extends State<LoginView> {
  final form = GlobalKey<FormState>();
  final email = TextEditingController(), password = TextEditingController(), invite = TextEditingController();
  bool register = false, hidden = true;
  @override void dispose() { email.dispose(); password.dispose(); invite.dispose(); super.dispose(); }
  void submit() {
    if (form.currentState!.validate()) {
      widget.model.login(email.text.trim(), password.text, invite.text.trim(), register);
    }
  }
  @override Widget build(BuildContext context) {
    final m = widget.model;
    return Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.fromLTRB(26, 22, 20, 18), child: Row(children: [const Icon(Icons.view_in_ar_outlined, color: brandBlue, size: 29), const SizedBox(width: 10), const Text('SXZ Hosting', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20, letterSpacing: -.5)), const Spacer(), IconButton(tooltip: 'Cambiar tema', onPressed: () => m.setDarkMode(!m.darkMode), icon: Icon(m.darkMode ? Icons.light_mode_outlined : Icons.dark_mode_outlined))])),
      const Padding(padding: EdgeInsets.symmetric(horizontal: 26), child: Text('Un lugar para\ntus próximos mundos.', style: TextStyle(fontSize: 35, fontWeight: FontWeight.w800, height: 1.1, letterSpacing: -1.3))),
      const SizedBox(height: 22), const ClipRRect(borderRadius: BorderRadius.vertical(top: Radius.circular(28)), child: WorldScene(height: 218)),
      Container(padding: const EdgeInsets.fromLTRB(26, 28, 26, 30), color: Theme.of(context).colorScheme.surface, child: AutofillGroup(child: Form(key: form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        AnimatedSwitcher(duration: const Duration(milliseconds: 180), child: Align(key: ValueKey(register), alignment: Alignment.centerLeft, child: Text(register ? 'Crea tu cuenta' : 'Qué bueno verte.', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700, letterSpacing: -.8)))),
        const SizedBox(height: 8), Text(register ? 'Guarda tus servidores, monedas y archivos en un mismo lugar.' : 'Entra para continuar donde lo dejaste.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.5)),
        const SizedBox(height: 24),
        TextFormField(controller: email, keyboardType: TextInputType.emailAddress, textInputAction: TextInputAction.next, autofillHints: const [AutofillHints.email], decoration: const InputDecoration(labelText: 'Correo electrónico', prefixIcon: Icon(Icons.mail_outline, size: 21)), validator: (v) => v != null && v.contains('@') && v.contains('.') ? null : 'Escribe un correo válido'),
        const SizedBox(height: 12), TextFormField(controller: password, obscureText: hidden, textInputAction: TextInputAction.done, autofillHints: [register ? AutofillHints.newPassword : AutofillHints.password], onFieldSubmitted: (_) { if (!m.busy) { submit(); } }, decoration: InputDecoration(labelText: 'Contraseña', helperText: register ? 'Usa al menos 10 caracteres' : null, prefixIcon: const Icon(Icons.lock_outline, size: 21), suffixIcon: IconButton(tooltip: hidden ? 'Mostrar contraseña' : 'Ocultar contraseña', onPressed: () => setState(() => hidden = !hidden), icon: Icon(hidden ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 20))), validator: (v) => (v?.length ?? 0) >= 10 ? null : 'Usa al menos 10 caracteres'),
        if (register && m.config['registration_invite'] == true) Padding(padding: const EdgeInsets.only(top: 12), child: TextFormField(controller: invite, decoration: const InputDecoration(labelText: 'Código de invitación'))),
        if (m.message.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 16), child: Text(m.message, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        const SizedBox(height: 22), FilledButton(onPressed: m.busy || m.config.isEmpty ? null : submit, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [if (m.busy) ...[const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2)), const SizedBox(width: 10)], Text(register ? 'Crear cuenta' : 'Entrar'), const SizedBox(width: 10), const Icon(Icons.arrow_forward, size: 19)])),
        const SizedBox(height: 10), TextButton(onPressed: m.busy ? null : () => setState(() => register = !register), child: Text(register ? 'Ya tengo cuenta · Iniciar sesión' : '¿Primera vez? Crea tu cuenta')),
        if (m.config.isEmpty) TextButton(onPressed: m.busy ? null : m.initialize, child: const Text('Reintentar conexión')),
        if (m.demo) const Padding(padding: EdgeInsets.only(top: 10), child: Text('Estás en una versión de prueba. Los servidores y las recompensas son simulados.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, height: 1.5))),
      ])))),
    ]))))));
  }
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key, required this.model});
  final HostingModel model;
  @override Widget build(BuildContext context) => RefreshIndicator(onRefresh: () async { await model.refresh(); }, child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.fromLTRB(22, 14, 22, 32), children: [Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 840), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Tu espacio de juego', style: TextStyle(fontSize: 15)), const SizedBox(height: 7), const Text('Todo listo para\nla próxima partida.', style: TextStyle(fontSize: 32, height: 1.1, letterSpacing: -1.2, fontWeight: FontWeight.w800)), const SizedBox(height: 24),
    ClipRRect(borderRadius: BorderRadius.circular(22), child: const WorldScene(height: 175)),
    SectionTitle('Tus servidores', action: model.servers.isEmpty ? null : Text('${model.servers.length} / 1', style: const TextStyle(fontSize: 13))),
    if (model.servers.isEmpty) Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('El primer mundo es tuyo.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)), const SizedBox(height: 10), Text('Minecraft Java · ${model.hours} horas iniciales.\nUn servidor por cuenta.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.6)), const SizedBox(height: 20), FilledButton.icon(onPressed: model.busy ? null : () => createDialog(context, model), icon: const Icon(Icons.add), label: const Text('Crear servidor'))])),
    for (final s in model.servers) Padding(padding: const EdgeInsets.only(bottom: 12), child: Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(14)), child: Icon(Icons.landscape_outlined, color: Theme.of(context).colorScheme.primary, size: 26)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(s.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)), const Text('Minecraft Java', style: TextStyle(fontSize: 13))])), const SizedBox(width: 8), StatusPill(s.status.startsWith('provisioning') ? 'Revisar' : s.expired ? 'Vencido' : 'Disponible')]),
      const SizedBox(height: 22), Row(children: [Expanded(child: _Summary('RAM', '${s.memory} MB')), Expanded(child: _Summary('CPU', '${s.cpu}%')), Expanded(child: _Summary('Disco', '${s.disk} MB'))]), const SizedBox(height: 22), const Divider(), const SizedBox(height: 14),
      Row(children: [const Icon(Icons.schedule, size: 18), const SizedBox(width: 7), Expanded(child: Text(s.timeLabel, style: const TextStyle(fontWeight: FontWeight.w600))), TextButton(onPressed: model.busy ? null : () => model.select(s), child: const Text('Administrar →'))]),
      if (!s.expired && s.remaining.inMinutes < 60) Padding(padding: const EdgeInsets.only(top: 10), child: Text('Queda menos de una hora. Renueva desde Monedas.', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.error))),
    ]))),
    const SectionTitle('Un poco más de juego'),
    Panel(child: Row(children: [const Icon(Icons.toll_outlined, color: brandBlue, size: 30), const SizedBox(width: 15), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${model.balance} monedas', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)), const Text('Tiempo y recursos para tu mundo.', style: TextStyle(fontSize: 13))])), IconButton(tooltip: 'Abrir tienda', onPressed: model.busy ? null : () => openWallet(context, model), icon: const Icon(Icons.arrow_forward))])),
    const SizedBox(height: 18), Text(model.demo ? 'Pruebas sin servidores reales ni ingresos publicitarios.' : 'Tus archivos se conservan al agotar el tiempo.', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
  ])))]));
}
class _Summary extends StatelessWidget {
  const _Summary(this.label, this.value);
  final String label, value;
  @override Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)), const SizedBox(height: 5), Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))]);
}

class DetailView extends StatefulWidget {
  const DetailView({super.key, required this.model});
  final HostingModel model;
  @override State<DetailView> createState() => _DetailViewState();
}
class _DetailViewState extends State<DetailView> {
  int tab = 0;
  String fileQuery = '', logQuery = '';
  bool newestFirst = false, errorsOnly = false;
  final command = TextEditingController();
  @override void dispose() { command.dispose(); super.dispose(); }
  Future<void> copy(String value, String message) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (mounted) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message))); }
  }
  Future<void> power(String signal) async {
    final m = widget.model;
    if (signal != 'start') {
      final yes = await confirm(context, signal == 'restart' ? '¿Reiniciar el servidor?' : '¿Detener el servidor?', 'Los jugadores conectados perderán la conexión. Guarda los cambios importantes antes de continuar.');
      if (!yes || !mounted) { return; }
    }
    await m.power(signal);
  }
  void send(String value) { if (value.trim().isNotEmpty && !widget.model.busy) { widget.model.command(value.trim()); command.clear(); } }
  @override Widget build(BuildContext context) {
    final m = widget.model, s = m.selected!;
    final address = m.resources['address']?.toString() ?? '';
    final state = m.resources['state']?.toString() ?? s.status;
    final online = state == 'running';
    final files = m.files.where((f) => f.name.toLowerCase().contains(fileQuery.toLowerCase())).toList()..sort((a, b) { if (a.isDir != b.isDir) { return a.isDir ? -1 : 1; } return a.name.toLowerCase().compareTo(b.name.toLowerCase()); });
    var logs = m.console.split('\n').where((line) => line.toLowerCase().contains(logQuery.toLowerCase()) && (!errorsOnly || RegExp(r'error|warn|exception', caseSensitive: false).hasMatch(line))).toList();
    if (newestFirst) { logs = logs.reversed.toList(); }
    return ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 32), children: [Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 840), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      StatusPill(s.expired ? 'Tiempo agotado' : online ? 'En línea' : state == 'offline' ? 'Apagado' : state == 'starting' ? 'Iniciando' : 'Estado: $state', online: online), const SizedBox(height: 14), Text(s.name, style: const TextStyle(fontSize: 32, letterSpacing: -1, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8), Row(children: [Expanded(child: Text(address.isEmpty ? 'Dirección pendiente de instalación' : address, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant))), IconButton(tooltip: 'Copiar dirección', onPressed: address.isEmpty ? null : () => copy(address, 'Dirección copiada'), icon: const Icon(Icons.copy_outlined, size: 19))]),
      const SizedBox(height: 20), Row(children: [Expanded(child: FilledButton.icon(onPressed: m.busy || s.expired || s.status.startsWith('provisioning') ? null : () => power('start'), icon: const Icon(Icons.play_arrow_rounded), label: const Text('Iniciar'))), const SizedBox(width: 10), IconButton.filledTonal(tooltip: 'Reiniciar', onPressed: m.busy ? null : () => power('restart'), icon: const Icon(Icons.restart_alt)), const SizedBox(width: 6), IconButton.filledTonal(tooltip: 'Detener', onPressed: m.busy ? null : () => power('stop'), icon: const Icon(Icons.stop_rounded))]),
      const SizedBox(height: 22), Panel(child: Column(children: [Row(children: [Expanded(child: _Summary('Memoria usada', '${((m.resources['memory_bytes'] as num? ?? 0) / 1048576).round()} MB')), Expanded(child: _Summary('CPU usada', '${(m.resources['cpu_absolute'] as num? ?? 0).toStringAsFixed(1)}%'))]), const SizedBox(height: 16), const Divider(), const SizedBox(height: 14), Row(children: [const Icon(Icons.schedule, size: 18), const SizedBox(width: 8), Expanded(child: Text(s.timeLabel)), TextButton(onPressed: m.busy ? null : () => openWallet(context, m), child: const Text('Renovar'))])])),
      const SizedBox(height: 24), SizedBox(width: double.infinity, child: SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('Consola')), ButtonSegment(value: 1, label: Text('Archivos')), ButtonSegment(value: 2, label: Text('Ajustes'))], selected: {tab}, onSelectionChanged: (v) => setState(() => tab = v.first), showSelectedIcon: false)),
      if (tab == 0) ...[
        SectionTitle('Consola', action: IconButton(tooltip: 'Copiar registros visibles', onPressed: logs.isEmpty ? null : () => copy(logs.join('\n'), 'Registros copiados'), icon: const Icon(Icons.copy_outlined, size: 20))),
        TextField(onChanged: (v) => setState(() => logQuery = v), decoration: const InputDecoration(hintText: 'Buscar en los registros', prefixIcon: Icon(Icons.search))),
        Wrap(spacing: 8, children: [FilterChip(label: const Text('Errores y avisos'), selected: errorsOnly, onSelected: (v) => setState(() => errorsOnly = v)), FilterChip(label: const Text('Recientes primero'), selected: newestFirst, onSelected: (v) => setState(() => newestFirst = v)), FilterChip(label: const Text('En vivo'), selected: m.liveRefresh, onSelected: m.setLiveRefresh)]),
        Container(height: 290, width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFF152333), borderRadius: BorderRadius.circular(18)), child: SingleChildScrollView(reverse: !newestFirst, child: SelectableText(logs.join('\n').trim().isEmpty ? 'Sin registros que coincidan.' : logs.join('\n'), style: const TextStyle(fontFamily: 'monospace', fontSize: 12, height: 1.65, color: Color(0xFFD8E4F1))))),
        const SizedBox(height: 12), Row(children: [Expanded(child: TextField(controller: command, autocorrect: false, enableSuggestions: false, decoration: const InputDecoration(hintText: 'Escribe un comando'), onSubmitted: send)), const SizedBox(width: 8), IconButton.filled(tooltip: 'Enviar comando', onPressed: m.busy ? null : () => send(command.text), icon: const Icon(Icons.arrow_upward))]),
        const SizedBox(height: 14), Wrap(spacing: 8, runSpacing: 6, children: [ActionChip(label: const Text('Jugadores'), avatar: const Icon(Icons.group_outlined, size: 18), onPressed: m.busy ? null : () => send('list')), ActionChip(label: const Text('Guardar mundo'), avatar: const Icon(Icons.save_outlined, size: 18), onPressed: m.busy ? null : () => send('save-all')), ActionChip(label: const Text('Lista blanca'), avatar: const Icon(Icons.verified_user_outlined, size: 18), onPressed: m.busy ? null : () => whitelistDialog(context, m))]),
        const SizedBox(height: 12), Text(m.liveRefresh ? 'Actualización cada 15 segundos.' : 'Actualización automática pausada. Puedes usar Actualizar.', style: const TextStyle(fontSize: 12)),
      ],
      if (tab == 1) ...[
        const SectionTitle('Archivos'), TextField(key: ValueKey(m.directory), onChanged: (v) => setState(() => fileQuery = v), decoration: const InputDecoration(hintText: 'Buscar en esta carpeta', prefixIcon: Icon(Icons.search))), const SizedBox(height: 12),
        Row(children: [IconButton(tooltip: 'Carpeta superior', onPressed: m.busy || m.directory == '/' ? null : () { final parts = m.directory.split('/')..removeLast(); setState(() => fileQuery = ''); m.openDirectory(parts.join('/').isEmpty ? '/' : parts.join('/')); }, icon: const Icon(Icons.arrow_upward)), Expanded(child: Text(m.directory, overflow: TextOverflow.ellipsis)), IconButton(tooltip: 'Nueva carpeta', onPressed: m.busy ? null : () async { final name = await askText(context, 'Nueva carpeta'); if (name != null) { await m.fileAction('mkdir', join(m.directory, name)); } }, icon: const Icon(Icons.create_new_folder_outlined)), IconButton(tooltip: 'Subir archivo', onPressed: m.busy ? null : () => upload(context, m), icon: const Icon(Icons.upload_file_outlined))]),
        const SizedBox(height: 8), Panel(padding: EdgeInsets.zero, child: Column(children: [if (files.isEmpty) const Padding(padding: EdgeInsets.all(28), child: Text('No hay archivos que coincidan.')), for (final f in files) ListTile(leading: Icon(f.isDir ? Icons.folder_outlined : Icons.description_outlined, color: Theme.of(context).colorScheme.primary), title: Text(f.name), subtitle: Text(f.isDir ? 'Carpeta' : '${(f.size / 1024).toStringAsFixed(1)} KB'), onTap: m.busy ? null : () { if (f.isDir) { m.openDirectory(f.path); setState(() => fileQuery = ''); } else { editFile(context, m, f); } }, trailing: PopupMenuButton<String>(enabled: !m.busy, onSelected: (action) async {
          switch (action) {
            case 'download': await download(context, m, f); break;
            case 'rename': final name = await askText(context, 'Renombrar', initial: f.name); if (name != null) { await m.fileAction('rename', f.path, join(m.directory, name)); } break;
            case 'delete': final yes = await confirm(context, '¿Eliminar ${f.name}?', 'Se eliminará el archivo o la carpeta con todo su contenido.'); if (yes) { await m.fileAction('delete', f.path); } break;
          }
        }, itemBuilder: (_) => [if (!f.isDir) const PopupMenuItem(value: 'download', child: Text('Descargar')), const PopupMenuItem(value: 'rename', child: Text('Renombrar')), const PopupMenuItem(value: 'delete', child: Text('Eliminar'))]))])),
        const SizedBox(height: 12), const Text('Hasta 5 MB por archivo. Editor de texto: hasta 512 KB.', style: TextStyle(fontSize: 12)),
      ],
      if (tab == 2) ...[
        const SectionTitle('Tu mundo, a tu manera'),
        Panel(child: Column(children: [ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.tune), title: const Text('Opciones de Minecraft'), subtitle: const Text('Nombre, dificultad, jugadores y PvP'), trailing: const Icon(Icons.chevron_right), onTap: m.busy || s.status.startsWith('provisioning') ? null : () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => WorldSettings(model: m, serverId: s.id)))), const Divider(), ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.login), title: const Text('Cómo conectarte'), subtitle: const Text('Minecraft Java en tu computadora'), trailing: const Icon(Icons.chevron_right), onTap: () => showDialog<void>(context: context, builder: (ctx) => AlertDialog(title: const Text('Conecta con tu mundo'), content: SelectableText(m.demo ? 'Esta versión simula servidores. Todavía no hay una dirección de juego real.\n\nEn modo real: abre Minecraft Java → Multijugador → Añadir servidor y pega la dirección del panel.' : 'Abre Minecraft Java → Multijugador → Añadir servidor.\n\nDirección: $address\n\nUsa una versión de Minecraft compatible con la instalada en el servidor.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Entendido'))])))])),
        const SectionTitle('Límites de tu servidor'), Panel(child: Row(children: [Expanded(child: _Summary('RAM', '${s.memory} MB')), Expanded(child: _Summary('CPU', '${s.cpu}%')), Expanded(child: _Summary('Disco', '${s.disk} MB'))])),
        const SizedBox(height: 24), TextButton.icon(onPressed: m.busy ? null : () async { if (await confirm(context, '¿Eliminar este servidor?', 'Se perderán su mundo y todos sus archivos. Esta acción es permanente.')) { await m.removeServer(); } }, icon: Icon(Icons.delete_outline, color: Theme.of(context).colorScheme.error), label: Text('Eliminar servidor', style: TextStyle(color: Theme.of(context).colorScheme.error))),
      ],
    ])))]);
  }
}

class AccountView extends StatelessWidget {
  const AccountView({super.key, required this.model});
  final HostingModel model;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(22, 14, 22, 32), children: [
    const Text('A tu manera.', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: -1)), const SizedBox(height: 8), const Text('Preferencias y controles de tu cuenta.'),
    const SectionTitle('Preferencias'), Panel(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), child: Column(children: [SwitchListTile(title: const Text('Modo oscuro'), subtitle: const Text('También se aplica a la tienda y al editor'), value: model.darkMode, onChanged: model.setDarkMode), const Divider(), SwitchListTile(title: const Text('Actualizar automáticamente'), subtitle: const Text('Consulta el servidor cada 15 segundos'), value: model.liveRefresh, onChanged: model.setLiveRefresh)])),
    const SectionTitle('Servicio'), Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(model.demo ? 'Entorno de pruebas' : 'Servicio conectado', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)), const SizedBox(height: 8), Text(model.demo ? 'Los servidores, las métricas y las recompensas son simulados. Las cuentas y los cambios se guardan en este backend.' : 'Los recursos dependen de la capacidad disponible del operador.'), const SizedBox(height: 14), const Text('SXZ Hosting · 0.3.0', style: TextStyle(fontSize: 12)), if (model.rewards.available) TextButton(onPressed: model.busy ? null : () => model.run(model.rewards.privacy), child: const Text('Privacidad de anuncios'))])),
    const SectionTitle('Cuenta'), OutlinedButton.icon(onPressed: model.busy ? null : model.logout, icon: const Icon(Icons.logout), label: const Text('Cerrar sesión')), const SizedBox(height: 14), TextButton(onPressed: model.busy ? null : () async { if (await confirm(context, '¿Eliminar tu cuenta?', 'Primero elimina tu servidor. Se borrarán tu cuenta, tus monedas y tu historial. Esta acción es permanente.')) { await model.removeAccount(); } }, child: Text('Eliminar mi cuenta', style: TextStyle(color: Theme.of(context).colorScheme.error))),
  ]);
}

Future<void> whitelistDialog(BuildContext context, HostingModel model) async {
  var name = '';
  final action = await showDialog<String>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, set) => AlertDialog(title: const Text('Lista blanca'), content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Gestiona quién puede entrar cuando la lista blanca está activada. Se envían comandos de Minecraft al servidor.'), const SizedBox(height: 16), TextField(onChanged: (v) => set(() => name = v.trim()), decoration: const InputDecoration(labelText: 'Nombre de jugador Java', helperText: '3–16 caracteres: letras, números y _'))]), actions: [TextButton(onPressed: () => Navigator.pop(ctx, 'list'), child: const Text('Ver lista')), TextButton(onPressed: RegExp(r'^[A-Za-z0-9_]{3,16}$').hasMatch(name) ? () => Navigator.pop(ctx, 'remove') : null, child: const Text('Quitar')), FilledButton(onPressed: RegExp(r'^[A-Za-z0-9_]{3,16}$').hasMatch(name) ? () => Navigator.pop(ctx, 'add') : null, child: const Text('Añadir'))])));
  if (action != null) { await model.command(action == 'list' ? 'whitelist list' : 'whitelist $action $name'); }
}
String join(String directory, String name) => '${directory == '/' ? '' : directory}/$name';
Future<bool> confirm(BuildContext context, String title, String body) async => await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirmar'))])) ?? false;

Future<String?> askText(BuildContext context, String title, {String initial = ''}) async {
  var value = initial;
  return showDialog<String>(context: context, builder: (ctx) => AlertDialog(title: Text(title), content: TextFormField(initialValue: initial, autofocus: true, maxLength: 64, onChanged: (v) => value = v), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), FilledButton(onPressed: () { if (value.trim().isNotEmpty && !value.contains('/') && !value.contains('\\') && value != '.' && value != '..') { Navigator.pop(ctx, value.trim()); } }, child: const Text('Guardar'))]));
}
Future<void> createDialog(BuildContext context, HostingModel model) async {
  var name = 'Mi mundo'; var accepted = false;
  final result = await showDialog<String>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, set) => AlertDialog(title: const Text('Nuevo servidor'), content: Column(mainAxisSize: MainAxisSize.min, children: [
    TextFormField(initialValue: name, maxLength: 32, onChanged: (v) => name = v, decoration: const InputDecoration(labelText: 'Nombre del mundo')),
    const SizedBox(height: 12), const Text('Minecraft Java · plan gratuito'),
    CheckboxListTile(contentPadding: EdgeInsets.zero, value: accepted, onChanged: (v) => set(() => accepted = v ?? false), title: const Text('Acepto el EULA de Minecraft', style: TextStyle(fontSize: 13))),
    TextButton(onPressed: () => launchUrl(Uri.parse('https://www.minecraft.net/eula'), mode: LaunchMode.externalApplication), child: const Text('Leer EULA')),
  ]), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), FilledButton(onPressed: accepted && name.trim().length >= 2 ? () => Navigator.pop(ctx, name.trim()) : null, child: const Text('Crear'))])));
  if (result != null) await model.create(result);
}
Future<void> upload(BuildContext context, HostingModel model) async {
  try {
    final result = await FilePicker.platform.pickFiles(withData: true);
    if (result == null) return;
    final f = result.files.single;
    if (f.size > 5 * 1024 * 1024 || f.bytes == null) throw Exception('Selecciona un archivo de hasta 5 MB.');
    if (model.files.any((item) => item.name == f.name)) {
      if (!context.mounted || !await confirm(context, '¿Reemplazar ${f.name}?', 'Ya existe un archivo con este nombre.')) return;
    }
    await model.write(join(model.directory, f.name), f.bytes!);
  } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
}
Future<void> download(BuildContext context, HostingModel model, ServerFile file) async {
  await model.run(() async {
    final bytes = await model.repository.read(model.selected!.id, file.path);
    await FilePicker.platform.saveFile(dialogTitle: 'Guardar archivo', fileName: file.name, bytes: bytes);
  });
}
Future<void> editFile(BuildContext context, HostingModel model, ServerFile file) async {
  String? text;
  final ok = await model.run(() async {
    if (file.size > 512 * 1024) throw Exception('El editor admite textos de hasta 512 KB. Usa Descargar para archivos mayores.');
    final data = await model.repository.read(model.selected!.id, file.path);
    if (data.contains(0)) throw Exception('Este es un archivo binario. Usa Descargar.');
    text = utf8.decode(data);
  });
  if (!ok || !context.mounted) return;
  await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => Editor(model: model, path: file.path, initial: text!)));
}
class Editor extends StatefulWidget {
  const Editor({super.key, required this.model, required this.path, required this.initial});
  final HostingModel model; final String path, initial;
  @override State<Editor> createState() => _EditorState();
}
class _EditorState extends State<Editor> {
  late final controller = TextEditingController(text: widget.initial);
  bool saving = false;
  @override void dispose() { controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.path), actions: [TextButton(onPressed: saving ? null : () async {
    setState(() => saving = true);
    final ok = await widget.model.write(widget.path, Uint8List.fromList(utf8.encode(controller.text)));
    if (!context.mounted) return;
    setState(() => saving = false);
    if (ok) { Navigator.pop(context); } else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(widget.model.message))); }
  }, child: const Text('Guardar'))]), body: Padding(padding: const EdgeInsets.all(16), child: TextField(controller: controller, expands: true, maxLines: null, minLines: null, autocorrect: false, enableSuggestions: false, keyboardType: TextInputType.multiline, style: const TextStyle(fontFamily: 'monospace', fontSize: 13), decoration: const InputDecoration(border: InputBorder.none))));
}
