import 'package:flutter/material.dart';

const brandBlue = Color(0xFF2458D3);
const ink = Color(0xFF142334);

ThemeData hostingTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final scheme = ColorScheme.fromSeed(seedColor: brandBlue, brightness: brightness,
    primary: dark ? const Color(0xFF97B5FF) : brandBlue,
    surface: dark ? const Color(0xFF172433) : Colors.white);
  return ThemeData(
    useMaterial3: true, brightness: brightness, colorScheme: scheme,
    scaffoldBackgroundColor: dark ? const Color(0xFF0E1824) : const Color(0xFFF5F6F8),
    appBarTheme: AppBarTheme(backgroundColor: dark ? const Color(0xFF0E1824) : const Color(0xFFF5F6F8), surfaceTintColor: Colors.transparent, centerTitle: false, elevation: 0),
    dividerTheme: DividerThemeData(color: dark ? const Color(0xFF293949) : const Color(0xFFE7EBF0), space: 1),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: dark ? const Color(0xFF213041) : const Color(0xFFF0F3F7), contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 18), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(minimumSize: const Size(48, 52), padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)))),
    outlinedButtonTheme: OutlinedButtonThemeData(style: OutlinedButton.styleFrom(minimumSize: const Size(48, 50), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)))),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: scheme.surface, indicatorColor: dark ? const Color(0xFF293D5D) : const Color(0xFFE8EEFE), height: 74),
  );
}

class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(20)});
  final Widget child;
  final EdgeInsetsGeometry padding;
  @override Widget build(BuildContext context) => Container(width: double.infinity, padding: padding,
    decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(22), border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .1))), child: child);
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.action});
  final String title;
  final Widget? action;
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(top: 26, bottom: 14), child: Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, letterSpacing: -.5))), if (action != null) action!]));
}

class StatusPill extends StatelessWidget {
  const StatusPill(this.label, {super.key, this.online = false});
  final String label;
  final bool online;
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: online ? const Color(0xFFE7F3EB) : const Color(0xFFEEF1F6), borderRadius: BorderRadius.circular(20)), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.circle, size: 7, color: online ? const Color(0xFF2A7951) : const Color(0xFF64758A)), const SizedBox(width: 6), Flexible(child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: online ? const Color(0xFF246443) : const Color(0xFF52647A))))]));
}

class WorldScene extends StatelessWidget {
  const WorldScene({super.key, this.height = 210});
  final double height;
  @override Widget build(BuildContext context) => Semantics(label: 'Ilustración de un mundo con montañas, árboles y un pequeño refugio', image: true, child: SizedBox(height: height, width: double.infinity, child: CustomPaint(painter: _WorldPainter())));
}

// Original vector artwork, rendered by Flutter. No remote images or stock assets.
class _WorldPainter extends CustomPainter {
  @override void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 400, size.height / 240);
    void polygon(List<Offset> points, Color color) {
      final path = Path()..addPolygon(points, true);
      canvas.drawPath(path, Paint()..color = color);
    }
    void rect(double x, double y, double w, double h, Color color) => canvas.drawRect(Rect.fromLTWH(x, y, w, h), Paint()..color = color);
    canvas.drawRect(const Rect.fromLTWH(0, 0, 400, 240), Paint()..color = const Color(0xFFE7F0F7));
    canvas.drawCircle(const Offset(313, 51), 26, Paint()..color = const Color(0xFFF3D9A5));
    for (final p in [const Offset(60, 41), const Offset(226, 29)]) {
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(p.dx, p.dy, 52, 12), const Radius.circular(8)), Paint()..color = Colors.white.withValues(alpha: .85));
      canvas.drawCircle(Offset(p.dx + 25, p.dy), 12, Paint()..color = Colors.white.withValues(alpha: .85));
    }
    polygon([const Offset(0, 151), const Offset(69, 70), const Offset(153, 160)], const Color(0xFFC1D3DE));
    polygon([const Offset(69, 70), const Offset(153, 160), const Offset(82, 158)], const Color(0xFFAFC7D4));
    polygon([const Offset(202, 155), const Offset(278, 81), const Offset(369, 161)], const Color(0xFFCEDDE4));
    polygon([const Offset(0, 179), const Offset(127, 124), const Offset(252, 156), const Offset(400, 119), const Offset(400, 240), const Offset(0, 240)], const Color(0xFF9EBBA5));
    polygon([const Offset(0, 213), const Offset(129, 165), const Offset(267, 190), const Offset(400, 150), const Offset(400, 240), const Offset(0, 240)], const Color(0xFF668D79));
    polygon([const Offset(171, 180), const Offset(220, 174), const Offset(289, 240), const Offset(239, 240)], const Color(0xFFD9C8A8));
    // Isometric refuge: stone base, blue roof, warm window.
    polygon([const Offset(207, 132), const Offset(250, 118), const Offset(288, 139), const Offset(247, 155)], const Color(0xFFECDBC1));
    polygon([const Offset(207, 132), const Offset(247, 155), const Offset(247, 189), const Offset(207, 168)], const Color(0xFFF5E7D1));
    polygon([const Offset(247, 155), const Offset(288, 139), const Offset(288, 174), const Offset(247, 189)], const Color(0xFFD1BFA2));
    polygon([const Offset(199, 133), const Offset(229, 98), const Offset(270, 121), const Offset(247, 158)], const Color(0xFF2B526A));
    polygon([const Offset(229, 98), const Offset(259, 89), const Offset(299, 134), const Offset(270, 121)], const Color(0xFF3E6F86));
    polygon([const Offset(259, 89), const Offset(299, 134), const Offset(270, 145), const Offset(270, 121)], const Color(0xFF203C55));
    polygon([const Offset(220, 151), const Offset(232, 157), const Offset(232, 175), const Offset(220, 169)], const Color(0xFF304D5B));
    polygon([const Offset(259, 158), const Offset(274, 153), const Offset(274, 163), const Offset(259, 169)], const Color(0xFFF9DC87));
    void tree(double x, double y, double scale) {
      canvas.save(); canvas.translate(x, y); canvas.scale(scale);
      rect(-3, -8, 6, 30, const Color(0xFF6D6652));
      polygon([const Offset(0, -57), const Offset(24, -16), const Offset(-24, -16)], const Color(0xFF315B54));
      polygon([const Offset(0, -75), const Offset(20, -39), const Offset(-20, -39)], const Color(0xFF417267));
      polygon([const Offset(0, -75), const Offset(0, -16), const Offset(-24, -16), const Offset(-12, -39)], const Color(0xFF527C6A));
      canvas.restore();
    }
    tree(68, 171, .9); tree(111, 155, .65); tree(345, 196, 1.1); tree(27, 218, .75);
    rect(139, 185, 9, 6, const Color(0xFFB8CCB6)); rect(154, 181, 5, 4, const Color(0xFFB8CCB6));
    rect(308, 214, 8, 5, const Color(0xFF8AA995));
    canvas.restore();
  }
  @override bool shouldRepaint(covariant _WorldPainter oldDelegate) => false;
}
