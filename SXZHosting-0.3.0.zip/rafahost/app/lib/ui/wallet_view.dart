import 'package:flutter/material.dart';
import 'design.dart';
import 'hosting_model.dart';

void openWallet(BuildContext context, HostingModel model) {
  Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => WalletView(model: model)));
}

class WalletView extends StatelessWidget {
  const WalletView({super.key, required this.model});
  final HostingModel model;
  @override Widget build(BuildContext context) => ListenableBuilder(listenable: model, builder: (context, _) => Scaffold(appBar: AppBar(title: const Text('Monedas y recursos')), body: Column(children: [if (model.busy) const LinearProgressIndicator(minHeight: 2), Expanded(child: WalletContent(model: model))])));
}

class WalletContent extends StatefulWidget {
  const WalletContent({super.key, required this.model});
  final HostingModel model;
  @override State<WalletContent> createState() => _WalletContentState();
}
class _WalletContentState extends State<WalletContent> {
  String historyFilter = 'all';
  @override Widget build(BuildContext context) {
    final m = widget.model;
    final server = m.selected ?? (m.servers.isEmpty ? null : m.servers.first);
    final history = ((m.wallet['history'] as List?) ?? []).where((e) => historyFilter == 'all' || (historyFilter == 'earned' ? (e['delta'] as num) > 0 : (e['delta'] as num) < 0)).toList();
    final pending = ((m.wallet['orders'] as List?) ?? []).where((o) => o['status'] == 'pending').toList();
    final colors = Theme.of(context).colorScheme;
    return RefreshIndicator(onRefresh: () async { await m.run(m.loadWallet); }, child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.fromLTRB(22, 14, 22, 32), children: [Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 840), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Más espacio\npara tus ideas.', style: TextStyle(fontSize: 32, height: 1.1, fontWeight: FontWeight.w800, letterSpacing: -1.1)), const SizedBox(height: 24),
      Container(width: double.infinity, padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: const Color(0xFF203D65), borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.toll_outlined, color: Color(0xFFF2D79C)), SizedBox(width: 9), Text('Tu monedero', style: TextStyle(color: Color(0xFFDFE8F5), fontSize: 14))]), const SizedBox(height: 18),
        Wrap(crossAxisAlignment: WrapCrossAlignment.end, spacing: 10, children: [Text('${m.balance}', style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.w700, letterSpacing: -2)), const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('monedas', style: TextStyle(color: Color(0xFFDFE8F5), fontSize: 16)))]),
        const SizedBox(height: 16), const Text('Gánalas a tu ritmo. Úsalas en tu servidor.', style: TextStyle(color: Color(0xFFDFE8F5), height: 1.5)),
      ])), const SizedBox(height: 14),
      Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Icon(Icons.play_circle_outline, color: brandBlue, size: 31), const SizedBox(width: 12), Expanded(child: Text(m.demo ? 'Prueba una recompensa' : 'Un anuncio, más posibilidades', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)))]), const SizedBox(height: 12), Text(m.demo ? 'Añade ${m.adCoins} monedas de prueba. No se muestra publicidad ni se generan ingresos.' : 'Recibe ${m.adCoins} monedas cuando el proveedor confirme el anuncio. Hasta ${m.config['daily_ads'] ?? 20} al día (UTC).', style: TextStyle(color: colors.onSurfaceVariant, height: 1.5)), const SizedBox(height: 18), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: m.busy || !m.signedIn ? null : () async {
        if (m.demo) {
          final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Recompensa de prueba'), content: Text('Se añadirán ${m.adCoins} monedas de prueba a tu cuenta. No se reproducirá un anuncio real.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Probar'))]));
          if (yes != true) { return; }
        }
        await m.earnCoins();
      }, icon: const Icon(Icons.add, size: 20), label: Text(m.demo ? 'Probar · ${m.adCoins} monedas' : 'Ver anuncio · ${m.adCoins} monedas')))])),
      if (m.message.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 14), child: Text(m.message, style: TextStyle(color: colors.primary))),
      if (pending.isNotEmpty) const Padding(padding: EdgeInsets.only(top: 18), child: Text('Ampliación pendiente. Tus monedas están reservadas mientras el servicio confirma el cambio.')),
      const SectionTitle('Elige tu mejora'), Text(server == null ? 'Puedes ganar monedas ahora y crear tu servidor después.' : 'Para ${server.name}', style: TextStyle(color: colors.onSurfaceVariant)), const SizedBox(height: 16),
      for (final p in m.products) Padding(padding: const EdgeInsets.only(bottom: 12), child: Panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: colors.primaryContainer, borderRadius: BorderRadius.circular(12)), child: Icon(p['kind'] == 'time' ? Icons.schedule : p['kind'] == 'memory' ? Icons.memory : p['kind'] == 'disk' ? Icons.storage_outlined : Icons.speed, color: colors.primary)), const SizedBox(width: 13), Expanded(child: Text(p['title'] as String, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700))), Text('${p['cost']}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w700)), const SizedBox(width: 5), const Icon(Icons.toll_outlined, size: 19)]),
        const SizedBox(height: 14), Text(p['description'] as String, style: TextStyle(color: colors.onSurfaceVariant, height: 1.4)), const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: OutlinedButton(onPressed: m.busy || server == null || p['enabled'] != true || m.balance < (p['cost'] as num) || pending.isNotEmpty ? null : () async {
          final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: Text('Comprar ${p['title']}'), content: Text('Para ${server.name}. Se descontarán ${p['cost']} monedas.\n\n${p['description']}.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Comprar'))]));
          if (yes == true) { await m.buy(server.id, p['sku'] as String); }
        }, child: Text(p['enabled'] != true ? 'Sin capacidad disponible' : server == null ? 'Crea tu servidor primero' : m.balance < (p['cost'] as num) ? 'Faltan ${(p['cost'] as num).toInt() - m.balance} monedas' : 'Comprar mejora'))),
      ]))),
      const SectionTitle('Tus movimientos'), Wrap(spacing: 8, children: [for (final f in [('all', 'Todos'), ('earned', 'Ganadas'), ('spent', 'Compras')]) ChoiceChip(label: Text(f.$2), selected: historyFilter == f.$1, onSelected: (_) => setState(() => historyFilter = f.$1))]), const SizedBox(height: 10),
      Panel(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), child: Column(children: [if (history.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('No hay movimientos en este filtro.')), for (final e in history) ListTile(contentPadding: EdgeInsets.zero, leading: Icon((e['delta'] as num) > 0 ? Icons.south_west : Icons.north_east, size: 20, color: colors.primary), title: Text(e['reason'] as String, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)), subtitle: Text(DateTime.fromMillisecondsSinceEpoch(((e['created'] as num) * 1000).round()).toLocal().toString().substring(0, 16), style: const TextStyle(fontSize: 12)), trailing: Text('${(e['delta'] as num) > 0 ? '+' : ''}${e['delta']}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)))])),
      const SizedBox(height: 18), Text('Las monedas solo se usan en este servicio. No son dinero ni se transfieren entre cuentas.', style: TextStyle(color: colors.onSurfaceVariant, fontSize: 12, height: 1.5)),
    ])))]));
  }
}
