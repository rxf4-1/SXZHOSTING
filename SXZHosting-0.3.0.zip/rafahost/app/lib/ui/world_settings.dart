import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../domain/server_properties.dart';
import 'design.dart';
import 'hosting_model.dart';

class WorldSettings extends StatefulWidget {
  const WorldSettings({super.key, required this.model, required this.serverId});
  final HostingModel model;
  final String serverId;
  @override State<WorldSettings> createState() => _WorldSettingsState();
}
class _WorldSettingsState extends State<WorldSettings> {
  final form = GlobalKey<FormState>();
  final motd = TextEditingController(), players = TextEditingController();
  Map<String, String>? original;
  String difficulty = 'easy', gameMode = 'survival';
  bool pvp = true, whitelist = false, loading = true, saving = false;
  String error = '';
  static const defaults = {'motd': 'A Minecraft Server', 'max-players': '20', 'difficulty': 'easy', 'gamemode': 'survival', 'pvp': 'true', 'white-list': 'false'};
  @override void initState() { super.initState(); load(); }
  @override void dispose() { motd.dispose(); players.dispose(); super.dispose(); }
  Future<ServerProperties> read() async {
    final bytes = await widget.model.repository.read(widget.serverId, '/server.properties');
    if (bytes.length > 512 * 1024) { throw const FormatException('Archivo demasiado grande. Usa Archivos.'); }
    return ServerProperties(utf8.decode(bytes));
  }
  Future<void> load() async {
    setState(() { loading = true; error = ''; });
    try {
      final document = await read();
      if (!mounted) { return; }
      original = document.values;
      final v = {...defaults, ...original!};
      motd.text = v['motd']!; players.text = v['max-players']!;
      difficulty = switch (v['difficulty']) { '0' => 'peaceful', '1' => 'easy', '2' => 'normal', '3' => 'hard', final d => d! };
      gameMode = switch (v['gamemode']) { '0' => 'survival', '1' => 'creative', '2' => 'adventure', '3' => 'spectator', final g => g! };
      if (!['peaceful', 'easy', 'normal', 'hard'].contains(difficulty) || !['survival', 'creative', 'adventure', 'spectator'].contains(gameMode)) {
        throw const FormatException('Valores personalizados detectados. Usa el editor de Archivos.');
      }
      pvp = v['pvp'] == 'true'; whitelist = v['white-list'] == 'true';
    } catch (e) { if (mounted) { error = e.toString().replaceFirst('Exception: ', ''); } }
    if (mounted) { setState(() => loading = false); }
  }
  Future<void> save() async {
    if (!form.currentState!.validate() || original == null) { return; }
    setState(() { saving = true; error = ''; });
    final desired = {'motd': motd.text, 'max-players': players.text.trim(), 'difficulty': difficulty, 'gamemode': gameMode, 'pvp': pvp.toString(), 'white-list': whitelist.toString()};
    final updates = <String, String>{};
    for (final e in desired.entries) {
      // Numeric legacy values normalize only when their setting changes.
      var old = original![e.key] ?? defaults[e.key];
      if (e.key == 'difficulty') { old = switch (old) { '0' => 'peaceful', '1' => 'easy', '2' => 'normal', '3' => 'hard', final v => v }; }
      if (e.key == 'gamemode') { old = switch (old) { '0' => 'survival', '1' => 'creative', '2' => 'adventure', '3' => 'spectator', final v => v }; }
      if (e.value != old) { updates[e.key] = e.value; }
    }
    if (updates.isEmpty) { setState(() => saving = false); return; }
    final ok = await widget.model.run(() async {
      final latest = await read();
      final text = latest.merge(updates, original: original!);
      await widget.model.repository.write(widget.serverId, '/server.properties', Uint8List.fromList(utf8.encode(text)));
      original = ServerProperties(text).values;
    });
    if (!mounted) { return; }
    setState(() { saving = false; if (!ok) { error = widget.model.message; } });
    if (ok) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Opciones guardadas. Reinicia el servidor para aplicarlas.'))); }
  }
  @override Widget build(BuildContext context) => ListenableBuilder(listenable: widget.model, builder: (context, _) => Scaffold(
    appBar: AppBar(title: const Text('Opciones de Minecraft')),
    body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(22), children: [
      const Text('Hazlo tuyo.', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -1)), const SizedBox(height: 10), const Text('Los cambios se guardan en server.properties. Reinicia el servidor para aplicarlos; los jugadores se desconectarán durante el reinicio.', style: TextStyle(height: 1.5)), const SizedBox(height: 24),
      if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 18), child: Text(error, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      if (original == null) OutlinedButton(onPressed: load, child: const Text('Volver a cargar')),
      if (original != null) Form(key: form, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Panel(child: Column(children: [
          TextFormField(controller: motd, maxLength: 100, decoration: const InputDecoration(labelText: 'Mensaje de bienvenida', helperText: 'Se muestra en la lista de servidores'), validator: (v) => (v ?? '').contains('\n') || (v ?? '').contains('\r') ? 'Usa una sola línea' : null),
          const SizedBox(height: 16), TextFormField(controller: players, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Máximo de jugadores'), validator: (v) { final n = int.tryParse(v ?? ''); return n == null || n < 1 || n > 10000 ? 'Introduce un número entre 1 y 10000' : null; }),
          const SizedBox(height: 18), DropdownButtonFormField<String>(initialValue: difficulty, decoration: const InputDecoration(labelText: 'Dificultad'), items: const [DropdownMenuItem(value: 'peaceful', child: Text('Pacífico')), DropdownMenuItem(value: 'easy', child: Text('Fácil')), DropdownMenuItem(value: 'normal', child: Text('Normal')), DropdownMenuItem(value: 'hard', child: Text('Difícil'))], onChanged: (v) { if (v != null) { setState(() => difficulty = v); } }),
          const SizedBox(height: 18), DropdownButtonFormField<String>(initialValue: gameMode, decoration: const InputDecoration(labelText: 'Modo de juego predeterminado'), items: const [DropdownMenuItem(value: 'survival', child: Text('Supervivencia')), DropdownMenuItem(value: 'creative', child: Text('Creativo')), DropdownMenuItem(value: 'adventure', child: Text('Aventura')), DropdownMenuItem(value: 'spectator', child: Text('Espectador'))], onChanged: (v) { if (v != null) { setState(() => gameMode = v); } }),
          const SizedBox(height: 14), SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Combate entre jugadores'), value: pvp, onChanged: (v) => setState(() => pvp = v)), const Divider(), SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Lista blanca'), subtitle: const Text('Permite entrar solo a jugadores autorizados'), value: whitelist, onChanged: (v) => setState(() => whitelist = v)),
        ])),
        const SizedBox(height: 20), FilledButton.icon(onPressed: saving || widget.model.busy ? null : save, icon: const Icon(Icons.check), label: Text(saving ? 'Guardando…' : 'Guardar opciones')),
        const SizedBox(height: 10), TextButton(onPressed: saving || widget.model.busy ? null : load, child: const Text('Volver a cargar desde el servidor')),
      ])),
    ]),
  ));
}
