import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:rafahost/data/api.dart';
import 'package:rafahost/data/repository.dart';
import 'package:rafahost/domain/models.dart';
import 'package:rafahost/ui/design.dart';
import 'package:rafahost/ui/hosting_model.dart';
import 'package:rafahost/ui/screens.dart';
import 'package:rafahost/ui/wallet_view.dart';

HostingModel model() => HostingModel(HostingRepository(Api('https://example.test', client: MockClient((r) async {
  final data = r.url.path.endsWith('/shop') ? <Object>[] : r.url.path.endsWith('/wallet') ? <String, Object>{'balance': 20, 'history': [], 'orders': []} : <Object>[];
  return http.Response(jsonEncode(data), 200);
}))))..initialized = true..config = {'mode': 'demo', 'ad_coins': 10, 'daily_ads': 20};

void main() {
  for (final width in [320.0, 390.0]) {
    testWidgets('Login and registration fit a $width wide display', (tester) async {
      tester.view.physicalSize = Size(width, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final m = model();
      await tester.pumpWidget(MaterialApp(theme: hostingTheme(Brightness.light), home: Shell(model: m)));
      await tester.pumpAndSettle();
      expect(find.text('Qué bueno verte.'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.ensureVisible(find.text('¿Primera vez? Crea tu cuenta'));
      await tester.tap(find.text('¿Primera vez? Crea tu cuenta'));
      await tester.pumpAndSettle();
      expect(find.text('Crea tu cuenta'), findsOneWidget);
      expect(tester.takeException(), isNull);
      m.dispose();
    });
  }
  testWidgets('Server controls, file search and options fit a small phone', (tester) async {
    tester.view.physicalSize = const Size(320, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final m = model();
    m.repository.api.token = 'test';
    m.selected = GameServer(id: 'one', name: 'Mi mundo', status: 'offline', expires: DateTime.now().add(const Duration(hours: 3)));
    m.resources = {'address': 'play.example.test:25565', 'state': 'offline'};
    await tester.pumpWidget(MaterialApp(theme: hostingTheme(Brightness.light), home: Shell(model: m)));
    await tester.pumpAndSettle();
    expect(find.text('Mi mundo'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.ensureVisible(find.text('Archivos'));
    await tester.tap(find.text('Archivos'));
    await tester.pumpAndSettle();
    expect(find.text('Buscar en esta carpeta'), findsOneWidget);
    expect(tester.takeException(), isNull);
    m.dispose();
  });
  testWidgets('Wallet stays readable in light and dark themes', (tester) async {
    final m = model();
    for (final brightness in Brightness.values) {
      await tester.pumpWidget(MaterialApp(theme: hostingTheme(brightness), home: Scaffold(body: WalletContent(model: m))));
      await tester.pumpAndSettle();
      expect(find.text('Tu monedero'), findsOneWidget);
      expect(tester.takeException(), isNull);
    }
    m.dispose();
  });
}
