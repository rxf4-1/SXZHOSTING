import 'package:flutter_test/flutter_test.dart';
import 'package:rafahost/domain/server_properties.dart';

void main() {
  test('Preserves unknown options, comments and CRLF while changing selected values', () {
    final file = ServerProperties('# World\r\nlevel-name=my-world\r\npvp=true\r\nmotd=Hola\r\n');
    final result = file.merge({'pvp': 'false'}, original: file.values);
    expect(result, '# World\r\nlevel-name=my-world\r\npvp=false\r\nmotd=Hola\r\n');
  });
  test('Preserves a concurrent change to an unrelated field', () {
    final original = ServerProperties('pvp=true\nlevel-name=old\n').values;
    final current = ServerProperties('pvp=true\nlevel-name=new\n');
    expect(current.merge({'pvp': 'false'}, original: original), contains('level-name=new'));
  });
  test('Rejects conflicting concurrent change and accepts same target', () {
    final original = ServerProperties('max-players=20\n').values;
    final current = ServerProperties('max-players=30\n');
    expect(() => current.merge({'max-players': '40'}, original: original), throwsFormatException);
    expect(current.merge({'max-players': '30'}, original: original), contains('max-players=30'));
  });
  test('Escapes Unicode, newlines and backslashes rather than injecting options', () {
    final value = 'Mundo español\npvp=false\\test';
    final result = ServerProperties('').merge({'motd': value}, original: {});
    expect(result.split('\n').where((l) => l.isNotEmpty).length, 1);
    expect(ServerProperties(result).values['motd'], value);
  });
  test('Understands comments, colon separators and duplicate options', () {
    final file = ServerProperties('! comment=ignored\n#pvp=false\npvp:true\npvp = false\n');
    expect(file.values['pvp'], 'false');
    expect(file.merge({'pvp': 'true'}, original: file.values), '! comment=ignored\n#pvp=false\npvp=true\npvp=true\n');
  });
  test('Rejects complex continued properties instead of damaging them', () {
    expect(() => ServerProperties('motd=hello\\\nworld\n'), throwsFormatException);
  });
}
