"""Run with the backend virtualenv Python after npm ci in this directory."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import urllib.request
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory() as temp:
    server=subprocess.Popen([sys.executable,'-m','uvicorn','main:app','--host','127.0.0.1','--port','8001'],cwd=root/'backend',env={**os.environ,'HOSTING_MODE':'demo','DATABASE_PATH':str(Path(temp)/'test.sqlite3')},stdout=subprocess.DEVNULL)
    try:
        for attempt in range(50):
            try:
                urllib.request.urlopen('http://127.0.0.1:8001/api/health',timeout=1)
                break
            except OSError: time.sleep(.1)
        result=subprocess.run(['node',str(Path(__file__).parent/'test.cjs')],timeout=60)
        sys.exit(result.returncode)
    finally:
        server.terminate()
        server.wait(timeout=5)
