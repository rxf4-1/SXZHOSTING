import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:rafahost/data/api.dart';
import 'package:rafahost/data/repository.dart';
import 'package:rafahost/ui/hosting_model.dart';

void main() {
  test('Repository sends session token and parses server expiry', () async {
    final api = Api('https://example.test', client: MockClient((request) async {
      expect(request.headers['Authorization'], 'Bearer session');
      return http.Response(jsonEncode([{'id':'one','name':'World','status':'offline','expires':1800000000}]), 200);
    }))..token = 'session';
    final repo = HostingRepository(api);
    final result = await repo.servers();
    expect(result.single.id, 'one');
    expect(result.single.expires.millisecondsSinceEpoch, 1800000000000);
    api.close();
  });
  test('File paths are query encoded and binary bytes preserved', () async {
    final api = Api('https://example.test', client: MockClient((request) async {
      expect(request.url.queryParameters['path'], '/folder/a & b.txt');
      return http.Response.bytes([0, 255, 42], 200);
    }));
    final bytes = await HostingRepository(api).read('one', '/folder/a & b.txt');
    expect(bytes, [0,255,42]);
    api.close();
  });
  test('ViewModel surfaces provider error and clears loading state', () async {
    final api = Api('https://example.test', client: MockClient((request) async => http.Response('{"detail":"No quedan cupos"}', 409)));
    final model = HostingModel(HostingRepository(api));
    await model.create('World');
    expect(model.busy, false);
    expect(model.message, 'No quedan cupos');
    expect(model.servers, isEmpty);
    model.dispose();
  });
}
