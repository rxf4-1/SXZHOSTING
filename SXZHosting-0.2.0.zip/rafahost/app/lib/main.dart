import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'data/api.dart';
import 'data/repository.dart';
import 'ui/hosting_model.dart';
import 'ui/screens.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  const configured = String.fromEnvironment('API_BASE_URL');
  final base = configured.isNotEmpty ? configured : (kIsWeb ? Uri.base.origin : 'http://localhost:8000');
  final uri = Uri.parse(base);
  if (kReleaseMode && uri.scheme != 'https') {
    runApp(const MaterialApp(home: Scaffold(body: Center(child: Text('Configura API_BASE_URL con una dirección HTTPS.')))));
    return;
  }
  runApp(HostingApp(model: HostingModel(HostingRepository(Api(base)))));
}

class HostingApp extends StatefulWidget {
  const HostingApp({super.key, required this.model});
  final HostingModel model;
  @override State<HostingApp> createState() => _HostingAppState();
}
class _HostingAppState extends State<HostingApp> {
  @override void initState() { super.initState(); widget.model.initialize(); }
  @override void dispose() { widget.model.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => MaterialApp(
    title: 'SXZ Hosting', debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true, brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF101416),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFCFEC8D), brightness: Brightness.dark,
        primary: const Color(0xFFCFEC8D), surface: const Color(0xFF1B2124)),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF101416)),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF242B2E), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 18), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
    ),
    home: ListenableBuilder(listenable: widget.model, builder: (context, _) => Shell(model: widget.model)),
  );
}
