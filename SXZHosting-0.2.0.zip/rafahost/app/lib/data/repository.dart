import 'dart:typed_data';
import '../domain/models.dart';
import 'api.dart';

class HostingRepository {
  HostingRepository(this.api);
  final Api api;
  Future<Map<String, dynamic>> config() async => Map<String, dynamic>.from(await api.json('GET', '/config'));
  Future<void> signIn(String email, String password, String invite, bool register) async {
    final response = await api.json('POST', '/auth/${register ? 'register' : 'login'}', data: {'email': email, 'password': password, 'invite': invite});
    api.token = response['token'] as String;
  }
  Future<List<GameServer>> servers() async => (await api.json('GET', '/servers') as List).map((v) => GameServer.fromJson(Map<String, dynamic>.from(v))).toList();
  Future<void> create(String name) async { await api.json('POST', '/servers', data: {'name': name, 'accept_eula': true}); }
  Future<void> power(String id, String signal) async { await api.json('POST', '/servers/$id/power', data: {'signal': signal}); }
  Future<Map<String, dynamic>> resources(String id) async => Map<String, dynamic>.from(await api.json('GET', '/servers/$id/resources'));
  Future<List<ServerFile>> files(String id, String path) async => (await api.json('GET', '/servers/$id/files', query: {'path': path}) as List).map((v) => ServerFile.fromJson(Map<String, dynamic>.from(v))).toList();
  Future<Uint8List> read(String id, String path) async => (await api.request('GET', '/servers/$id/file', query: {'path': path})).bodyBytes;
  Future<void> write(String id, String path, Uint8List bytes) async { await api.request('PUT', '/servers/$id/file', query: {'path': path}, bytes: bytes); }
  Future<void> fileAction(String id, String action, String path, [String target = '']) async { await api.json('POST', '/servers/$id/files', data: {'action': action, 'path': path, 'target': target}); }
  Future<String> console(String id) async => (await api.json('GET', '/servers/$id/console'))['text'] as String;
  Future<void> command(String id, String command) async { await api.json('POST', '/servers/$id/command', data: {'command': command}); }
  Future<Map<String, dynamic>> intent() async => Map<String, dynamic>.from(await api.json('POST', '/wallet/reward-intent'));
  Future<bool> rewardStatus(String id) async => (await api.json('GET', '/wallet/reward-status/$id'))['credited'] == true;
  Future<Map<String, dynamic>> wallet() async => Map<String, dynamic>.from(await api.json('GET', '/wallet'));
  Future<List<Map<String, dynamic>>> catalog() async => (await api.json('GET', '/shop') as List).map((p) => Map<String, dynamic>.from(p)).toList();
  Future<Map<String, dynamic>> purchase(String id, String sku, String key) async => Map<String, dynamic>.from(await api.json('POST', '/shop/purchase', data: {'server_id': id, 'sku': sku, 'idempotency_key': key}));
  Future<void> demoReward(String intent) async { await api.json('POST', '/rewards/demo', data: {'intent': intent}); }
  Future<void> deleteServer(String id) async { await api.json('DELETE', '/servers/$id'); }
  Future<void> deleteAccount() async { await api.json('DELETE', '/account'); api.token = null; }
  Future<void> logout() async { await api.json('POST', '/auth/logout'); api.token = null; }
}
