import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

class ApiException implements Exception {
  ApiException(this.message, this.status);
  final String message;
  final int status;
  @override String toString() => message;
}

class Api {
  Api(this.base, {http.Client? client}) : client = client ?? http.Client();
  final String base;
  final http.Client client;
  String? token;
  Uri uri(String path, [Map<String, String>? query]) => Uri.parse('$base/api$path').replace(queryParameters: query);
  Future<http.Response> request(String method, String path, {Object? data, Map<String, String>? query, Uint8List? bytes}) async {
    final req = http.Request(method, uri(path, query));
    req.headers['Accept'] = 'application/json';
    if (token != null) req.headers['Authorization'] = 'Bearer $token';
    if (bytes != null) {
      req.headers['Content-Type'] = 'application/octet-stream';
      req.bodyBytes = bytes;
    } else if (data != null) {
      req.headers['Content-Type'] = 'application/json';
      req.body = jsonEncode(data);
    }
    try {
      final result = await client.send(req).then(http.Response.fromStream).timeout(const Duration(seconds: 45));
      if (result.statusCode >= 300) {
        var message = 'No se pudo completar la operación (${result.statusCode}).';
        try { final detail = jsonDecode(result.body)['detail']; if (detail is String) message = detail; } catch (_) {}
        throw ApiException(message, result.statusCode);
      }
      return result;
    } on ApiException { rethrow; }
    catch (_) { throw ApiException('No se pudo conectar. Comprueba Internet y la dirección del servicio.', 0); }
  }
  Future<dynamic> json(String method, String path, {Object? data, Map<String, String>? query}) async {
    final response = await request(method, path, data: data, query: query);
    return response.body.isEmpty ? null : jsonDecode(response.body);
  }
  void close() => client.close();
}
