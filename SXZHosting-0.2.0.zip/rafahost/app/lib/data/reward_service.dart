import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class RewardService {
  static const live = bool.fromEnvironment('ADMOB_LIVE', defaultValue: false);
  String get unit {
    if (!live) return defaultTargetPlatform == TargetPlatform.iOS
        ? 'ca-app-pub-3940256099942544/1712485313'
        : 'ca-app-pub-3940256099942544/5224354917';
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      return const String.fromEnvironment('ADMOB_REWARDED_ID', defaultValue: 'ca-app-pub-9419517058946613/5939841867');
    }
    return const String.fromEnvironment('ADMOB_REWARDED_ID');
  }
  bool get available => !kIsWeb && (defaultTargetPlatform == TargetPlatform.iOS || defaultTargetPlatform == TargetPlatform.android) && unit.isNotEmpty;

  Future<void> consent() async {
    final done = Completer<void>();
    ConsentInformation.instance.requestConsentInfoUpdate(ConsentRequestParameters(), () {
      ConsentForm.loadAndShowConsentFormIfRequired((error) {
        if (error != null) { done.completeError(Exception('No se pudo cargar el consentimiento publicitario.')); }
        else { done.complete(); }
      });
    }, (error) => done.completeError(Exception('No se pudo comprobar el consentimiento publicitario.')));
    await done.future;
    if (!await ConsentInformation.instance.canRequestAds()) throw Exception('Los anuncios no están disponibles con la configuración actual.');
    await MobileAds.instance.initialize();
  }

  Future<void> privacy() async {
    if (!available) return;
    final done = Completer<void>();
    ConsentForm.showPrivacyOptionsForm((error) {
      if (error == null) { done.complete(); } else { done.completeError(Exception(error.message)); }
    });
    await done.future;
  }

  Future<bool> show(String intent, String userId) async {
    if (!available) throw Exception('Los anuncios requieren la app móvil y una unidad AdMob configurada.');
    await consent();
    final loaded = Completer<RewardedAd>();
    RewardedAd.load(adUnitId: unit, request: const AdRequest(nonPersonalizedAds: true), rewardedAdLoadCallback: RewardedAdLoadCallback(
      onAdLoaded: loaded.complete,
      onAdFailedToLoad: (error) => loaded.completeError(Exception('No hay anuncios disponibles. Intenta más tarde.')),
    ));
    final ad = await loaded.future;
    try {
      await ad.setServerSideOptions(ServerSideVerificationOptions(customData: intent, userId: userId));
      final finished = Completer<bool>();
      var earned = false;
      ad.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) { ad.dispose(); if (!finished.isCompleted) finished.complete(earned); },
        onAdFailedToShowFullScreenContent: (ad, error) { ad.dispose(); if (!finished.isCompleted) finished.completeError(Exception('No se pudo mostrar el anuncio.')); },
      );
      ad.show(onUserEarnedReward: (ad, reward) { earned = true; });
      return await finished.future;
    } catch (_) { ad.dispose(); rethrow; }
  }
}
