import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../domain/models.dart';
import 'hosting_model.dart';
import 'wallet_view.dart';

const muted = Color(0xFF9AA7AC);

class Shell extends StatelessWidget {
  const Shell({super.key, required this.model});
  final HostingModel model;
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: model.selected != null ? IconButton(onPressed: model.busy ? null : model.back, icon: const Icon(Icons.arrow_back)) : null,
      title: const Text('SXZ / HOST', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: 2)),
      actions: [if (model.demo) const Chip(label: Text('DEMO', style: TextStyle(fontSize: 11))), if (model.signedIn) IconButton(tooltip: 'Monedas y tienda', onPressed: model.busy ? null : () => openWallet(context, model), icon: const Icon(Icons.account_balance_wallet_outlined)), if (model.signedIn) PopupMenuButton<String>(
        enabled: !model.busy,
        onSelected: (v) async {
          if (v == 'logout') await model.logout();
          if (v == 'privacy') await model.run(model.rewards.privacy);
          if (v == 'delete' && context.mounted && await confirm(context, '¿Eliminar tu cuenta?', 'Primero debes eliminar tu servidor. Esta acción es permanente.')) await model.removeAccount();
        }, itemBuilder: (_) => [const PopupMenuItem(value: 'logout', child: Text('Cerrar sesión')), if (model.rewards.available) const PopupMenuItem(value: 'privacy', child: Text('Privacidad de anuncios')), const PopupMenuItem(value: 'delete', child: Text('Eliminar cuenta'))],
      ), const SizedBox(width: 12)],
    ),
    body: SafeArea(child: Column(children: [
      if (model.busy) const LinearProgressIndicator(minHeight: 2),
      if (model.message.isNotEmpty) Container(width: double.infinity, padding: const EdgeInsets.all(14), color: const Color(0xFF33392A), child: Text(model.message)),
      Expanded(child: !model.initialized ? const Center(child: CircularProgressIndicator()) : !model.signedIn ? LoginView(model: model) : model.selected == null ? Dashboard(model: model) : DetailView(key: ValueKey(model.selected!.id), model: model)),
    ])),
  );
}

class LoginView extends StatefulWidget {
  const LoginView({super.key, required this.model});
  final HostingModel model;
  @override State<LoginView> createState() => _LoginViewState();
}
class _LoginViewState extends State<LoginView> {
  final form = GlobalKey<FormState>();
  final email = TextEditingController(), password = TextEditingController(), invite = TextEditingController();
  bool register = true;
  @override void dispose() { email.dispose(); password.dispose(); invite.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Form(key: form, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Icon(Icons.dns_rounded, size: 44, color: Color(0xFFCFEC8D)), const SizedBox(height: 32),
    const Text('Un mundo tuyo.\nSiempre a mano.', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w800, height: 1.05, letterSpacing: -1.8)),
    const SizedBox(height: 18), Text(widget.model.demo ? 'Prueba el panel con servidores simulados. Tus cambios se guardan en esta instalación.' : 'Tu servidor de Minecraft, sus archivos y tus amigos. Todo desde el móvil.', style: const TextStyle(color: muted, height: 1.5)),
    const SizedBox(height: 32),
    TextFormField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email], decoration: const InputDecoration(labelText: 'Correo electrónico'), validator: (v) => v != null && v.contains('@') && v.contains('.') ? null : 'Escribe un correo válido'),
    const SizedBox(height: 14),
    TextFormField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Contraseña', helperText: 'Mínimo 10 caracteres'), validator: (v) => (v?.length ?? 0) >= 10 ? null : 'Usa al menos 10 caracteres'),
    if (register && widget.model.config['registration_invite'] == true) Padding(padding: const EdgeInsets.only(top: 14), child: TextFormField(controller: invite, decoration: const InputDecoration(labelText: 'Código de invitación'))),
    const SizedBox(height: 24), SizedBox(width: double.infinity, child: FilledButton(onPressed: widget.model.busy ? null : () { if (form.currentState!.validate()) widget.model.login(email.text.trim(), password.text, invite.text.trim(), register); }, child: Text(register ? 'Crear mi cuenta' : 'Entrar'))),
    Center(child: TextButton(onPressed: widget.model.busy ? null : () => setState(() => register = !register), child: Text(register ? 'Ya tengo una cuenta' : 'Crear una cuenta'))),
    if (widget.model.config.isEmpty) Center(child: TextButton(onPressed: widget.model.busy ? null : widget.model.initialize, child: const Text('Reintentar conexión'))),
  ])))));
}

class Dashboard extends StatelessWidget {
  const Dashboard({super.key, required this.model});
  final HostingModel model;
  @override Widget build(BuildContext context) => RefreshIndicator(onRefresh: () async { await model.refresh(); }, child: ListView(padding: const EdgeInsets.all(24), children: [Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 960), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const SizedBox(height: 14), const Text('TU ESPACIO DE JUEGO', style: TextStyle(fontSize: 11, letterSpacing: 2.5, color: muted)), const SizedBox(height: 12),
    const Text('Mis servidores', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w800, letterSpacing: -1)),
    const SizedBox(height: 10), const Text('Menos configuración. Más aventuras.', style: TextStyle(color: muted)), const SizedBox(height: 18), FilledButton.tonalIcon(onPressed: model.busy ? null : () => openWallet(context, model), icon: const Icon(Icons.toll), label: Text('${model.balance} monedas · Tienda')), const SizedBox(height: 28),
    if (model.servers.isEmpty) Container(width: double.infinity, padding: const EdgeInsets.all(30), decoration: BoxDecoration(color: const Color(0xFF1B2124), borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.landscape_outlined, size: 64, color: Color(0xFFCFEC8D)), const SizedBox(height: 30), const Text('Tu primer mundo\nempieza aquí.', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)), const SizedBox(height: 12), Text('Minecraft Java · ${model.hours} horas iniciales\nUn servidor gratuito por cuenta.', style: const TextStyle(color: muted, height: 1.6)), const SizedBox(height: 24),
      FilledButton.icon(onPressed: model.busy ? null : () => createDialog(context, model), icon: const Icon(Icons.add), label: const Text('Crear servidor')),
    ])),
    for (final s in model.servers) Card(margin: const EdgeInsets.only(bottom: 16), child: InkWell(borderRadius: BorderRadius.circular(16), onTap: model.busy ? null : () => model.select(s), child: Padding(padding: const EdgeInsets.all(24), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.view_in_ar_rounded, size: 42, color: Color(0xFFCFEC8D)), const Spacer(), Chip(label: Text(s.status.startsWith('provisioning') ? 'Instalando / revisar' : s.expired ? 'Vencido' : 'Disponible'))]), const SizedBox(height: 24),
      Text(s.name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const Text('MINECRAFT JAVA', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1.6)), const SizedBox(height: 24), const Divider(), const SizedBox(height: 8), Row(children: [const Icon(Icons.schedule, size: 18), const SizedBox(width: 8), Text(s.timeLabel), const Spacer(), const Icon(Icons.arrow_forward)]),
    ])))),
    const SizedBox(height: 22), const Text('JUEGA A TU RITMO', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 2)), const SizedBox(height: 10), Text('Gana monedas viendo anuncios voluntarios. Úsalas para tiempo, RAM, CPU y disco.', style: const TextStyle(color: muted, height: 1.6)),
  ])))]));
}

class DetailView extends StatefulWidget {
  const DetailView({super.key, required this.model});
  final HostingModel model;
  @override State<DetailView> createState() => _DetailViewState();
}
class _DetailViewState extends State<DetailView> {
  int tab = 0;
  final command = TextEditingController();
  @override void dispose() { command.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final m = widget.model, s = widget.model.selected!;
    return ListView(padding: const EdgeInsets.all(20), children: [Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 960), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(s.name, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800)), const SizedBox(height: 8),
      Row(children: [Expanded(child: SelectableText(m.resources['address']?.toString() ?? 'Minecraft Java', style: const TextStyle(color: muted))), IconButton(tooltip: 'Actualizar', onPressed: m.busy ? null : m.refresh, icon: const Icon(Icons.refresh))]),
      const SizedBox(height: 16), Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.icon(onPressed: m.busy || s.expired || s.status.startsWith('provisioning') ? null : () => m.power('start'), icon: const Icon(Icons.play_arrow), label: const Text('Iniciar')),
        OutlinedButton.icon(onPressed: m.busy ? null : () => m.power('restart'), icon: const Icon(Icons.restart_alt), label: const Text('Reiniciar')),
        OutlinedButton.icon(onPressed: m.busy ? null : () => m.power('stop'), icon: const Icon(Icons.stop), label: const Text('Detener')),
      ]), const SizedBox(height: 24),
      Wrap(spacing: 12, runSpacing: 12, children: [metric('ESTADO', m.resources['state']?.toString() ?? s.status), metric('MEMORIA', '${((m.resources['memory_bytes'] as num? ?? 0) / 1048576).round()} MB'), metric('CPU', '${(m.resources['cpu_absolute'] as num? ?? 0).toStringAsFixed(1)}%')]),
      const SizedBox(height: 24), SizedBox(width: double.infinity, child: SegmentedButton<int>(segments: const [ButtonSegment(value: 0, label: Text('Consola'), icon: Icon(Icons.terminal)), ButtonSegment(value: 1, label: Text('Archivos'), icon: Icon(Icons.folder_outlined)), ButtonSegment(value: 2, label: Text('Tiempo'), icon: Icon(Icons.schedule))], selected: {tab}, onSelectionChanged: (v) => setState(() => tab = v.first), showSelectedIcon: false)),
      const SizedBox(height: 20),
      if (tab == 0) ...[
        const Text('Registro de Minecraft · se actualiza cada 15 s', style: TextStyle(color: muted, fontSize: 12)), const SizedBox(height: 10),
        Container(height: 300, width: double.infinity, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFF080D0F), borderRadius: BorderRadius.circular(16)), child: SingleChildScrollView(reverse: true, child: SelectableText(m.console.isEmpty ? 'Esperando al servidor…' : m.console, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, height: 1.6, color: Color(0xFFCFEC8D))))),
        const SizedBox(height: 12), Row(children: [Expanded(child: TextField(controller: command, decoration: const InputDecoration(hintText: 'Escribe un comando…'), onSubmitted: m.busy ? null : (text) { if (text.trim().isNotEmpty) { m.command(text); command.clear(); } })), IconButton(onPressed: m.busy ? null : () { if (command.text.trim().isNotEmpty) { m.command(command.text); command.clear(); } }, icon: const Icon(Icons.send))]),
      ],
      if (tab == 1) ...[
        Row(children: [IconButton(onPressed: m.busy || m.directory == '/' ? null : () { final parts = m.directory.split('/')..removeLast(); m.openDirectory(parts.join('/').isEmpty ? '/' : parts.join('/')); }, icon: const Icon(Icons.arrow_upward)), Expanded(child: Text(m.directory, overflow: TextOverflow.ellipsis)), IconButton(tooltip: 'Nueva carpeta', onPressed: m.busy ? null : () async { final name = await askText(context, 'Nueva carpeta'); if (name != null) m.fileAction('mkdir', join(m.directory, name)); }, icon: const Icon(Icons.create_new_folder_outlined)), IconButton(tooltip: 'Subir archivo', onPressed: m.busy ? null : () => upload(context, m), icon: const Icon(Icons.upload_file))]),
        const Text('Archivos de hasta 5 MB · toca un texto para editarlo', style: TextStyle(color: muted, fontSize: 12)), const SizedBox(height: 12),
        if (m.files.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Text('Esta carpeta está vacía.')),
        for (final f in m.files) Card(child: ListTile(leading: Icon(f.isDir ? Icons.folder : Icons.description_outlined, color: f.isDir ? const Color(0xFFCFEC8D) : muted), title: Text(f.name), subtitle: Text(f.isDir ? 'Carpeta' : '${(f.size / 1024).toStringAsFixed(1)} KB'), onTap: m.busy ? null : () { if (f.isDir) { m.openDirectory(f.path); } else { editFile(context, m, f); } }, trailing: PopupMenuButton<String>(enabled: !m.busy, onSelected: (action) async {
          if (action == 'download') await download(context, m, f);
          if (action == 'rename') { final name = await askText(context, 'Renombrar', initial: f.name); if (name != null) await m.fileAction('rename', f.path, join(m.directory, name)); }
          if (action == 'delete' && context.mounted && await confirm(context, '¿Eliminar ${f.name}?', 'Esta acción elimina el archivo o la carpeta y todo su contenido.')) await m.fileAction('delete', f.path);
        }, itemBuilder: (_) => [if (!f.isDir) const PopupMenuItem(value: 'download', child: Text('Descargar')), const PopupMenuItem(value: 'rename', child: Text('Renombrar')), const PopupMenuItem(value: 'delete', child: Text('Eliminar'))]))),
      ],
      if (tab == 2) Container(width: double.infinity, padding: const EdgeInsets.all(28), decoration: BoxDecoration(color: const Color(0xFF252F23), borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('TIEMPO DISPONIBLE', style: TextStyle(color: muted, letterSpacing: 2, fontSize: 11)), const SizedBox(height: 16), Text(s.timeLabel, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)), const SizedBox(height: 16), Text('Añade ${m.hours} horas. Puedes acumular hasta ${m.config['max_hours'] ?? 24} horas.', style: const TextStyle(color: muted)), const SizedBox(height: 24),
        FilledButton.icon(onPressed: m.busy ? null : () => openWallet(context, m), icon: const Icon(Icons.shopping_bag_outlined), label: Text('Renovar en la tienda · ${m.balance} monedas')),
      ])),
      const SizedBox(height: 36), TextButton.icon(onPressed: m.busy ? null : () async { if (await confirm(context, '¿Eliminar este servidor?', 'Se perderán su mundo y todos sus archivos. Esta acción es permanente.')) await m.removeServer(); }, icon: const Icon(Icons.delete_outline, color: Colors.redAccent), label: const Text('Eliminar servidor', style: TextStyle(color: Colors.redAccent))),
    ])))]);
  }
  Widget metric(String title, String value) => Container(width: 135, padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF1B2124), borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 10, letterSpacing: 1.3, color: muted)), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold))]));
}

String join(String directory, String name) => '${directory == '/' ? '' : directory}/$name';
Future<bool> confirm(BuildContext context, String title, String body) async => await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirmar'))])) ?? false;

Future<String?> askText(BuildContext context, String title, {String initial = ''}) async {
  var value = initial;
  return showDialog<String>(context: context, builder: (ctx) => AlertDialog(title: Text(title), content: TextFormField(initialValue: initial, autofocus: true, maxLength: 64, onChanged: (v) => value = v), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), FilledButton(onPressed: () { if (value.trim().isNotEmpty && !value.contains('/') && !value.contains('\\') && value != '.' && value != '..') Navigator.pop(ctx, value.trim()); }, child: const Text('Guardar'))]));
}
Future<void> createDialog(BuildContext context, HostingModel model) async {
  var name = 'Mi mundo'; var accepted = false;
  final result = await showDialog<String>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, set) => AlertDialog(title: const Text('Nuevo servidor'), content: Column(mainAxisSize: MainAxisSize.min, children: [
    TextFormField(initialValue: name, maxLength: 32, onChanged: (v) => name = v, decoration: const InputDecoration(labelText: 'Nombre del mundo')),
    const SizedBox(height: 12), const Text('Minecraft Java · plan gratuito'),
    CheckboxListTile(contentPadding: EdgeInsets.zero, value: accepted, onChanged: (v) => set(() => accepted = v ?? false), title: const Text('Acepto el EULA de Minecraft', style: TextStyle(fontSize: 13))),
    TextButton(onPressed: () => launchUrl(Uri.parse('https://www.minecraft.net/eula'), mode: LaunchMode.externalApplication), child: const Text('Leer EULA')),
  ]), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')), FilledButton(onPressed: accepted && name.trim().length >= 2 ? () => Navigator.pop(ctx, name.trim()) : null, child: const Text('Crear'))])));
  if (result != null) await model.create(result);
}
Future<void> upload(BuildContext context, HostingModel model) async {
  try {
    final result = await FilePicker.platform.pickFiles(withData: true);
    if (result == null) return;
    final f = result.files.single;
    if (f.size > 5 * 1024 * 1024 || f.bytes == null) throw Exception('Selecciona un archivo de hasta 5 MB.');
    if (model.files.any((item) => item.name == f.name)) {
      if (!context.mounted || !await confirm(context, '¿Reemplazar ${f.name}?', 'Ya existe un archivo con este nombre.')) return;
    }
    await model.write(join(model.directory, f.name), f.bytes!);
  } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
}
Future<void> download(BuildContext context, HostingModel model, ServerFile file) async {
  await model.run(() async {
    final bytes = await model.repository.read(model.selected!.id, file.path);
    await FilePicker.platform.saveFile(dialogTitle: 'Guardar archivo', fileName: file.name, bytes: bytes);
  });
}
Future<void> editFile(BuildContext context, HostingModel model, ServerFile file) async {
  String? text;
  final ok = await model.run(() async {
    if (file.size > 512 * 1024) throw Exception('El editor admite textos de hasta 512 KB. Usa Descargar para archivos mayores.');
    final data = await model.repository.read(model.selected!.id, file.path);
    if (data.contains(0)) throw Exception('Este es un archivo binario. Usa Descargar.');
    text = utf8.decode(data);
  });
  if (!ok || !context.mounted) return;
  await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => Editor(model: model, path: file.path, initial: text!)));
}
class Editor extends StatefulWidget {
  const Editor({super.key, required this.model, required this.path, required this.initial});
  final HostingModel model; final String path, initial;
  @override State<Editor> createState() => _EditorState();
}
class _EditorState extends State<Editor> {
  late final controller = TextEditingController(text: widget.initial);
  bool saving = false;
  @override void dispose() { controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.path), actions: [TextButton(onPressed: saving ? null : () async {
    setState(() => saving = true);
    final ok = await widget.model.write(widget.path, Uint8List.fromList(utf8.encode(controller.text)));
    if (!context.mounted) return;
    setState(() => saving = false);
    if (ok) { Navigator.pop(context); } else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(widget.model.message))); }
  }, child: const Text('Guardar'))]), body: Padding(padding: const EdgeInsets.all(16), child: TextField(controller: controller, expands: true, maxLines: null, minLines: null, autocorrect: false, enableSuggestions: false, keyboardType: TextInputType.multiline, style: const TextStyle(fontFamily: 'monospace', fontSize: 13), decoration: const InputDecoration(border: InputBorder.none))));
}
