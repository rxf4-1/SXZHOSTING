import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../data/api.dart';
import '../data/repository.dart';
import '../data/reward_service.dart';
import '../domain/models.dart';

class HostingModel extends ChangeNotifier {
  HostingModel(this.repository, {RewardService? rewards}) : rewards = rewards ?? RewardService();
  final HostingRepository repository;
  final RewardService rewards;
  final storage = const FlutterSecureStorage();
  Map<String, dynamic> config = {};
  Map<String, dynamic> wallet = {'balance': 0, 'history': [], 'orders': []};
  List<Map<String, dynamic>> products = [];
  final Map<String, String> purchaseKeys = {};
  int get balance => (wallet['balance'] as num).toInt();
  int get adCoins => (config['ad_coins'] as num?)?.toInt() ?? 10;
  List<GameServer> _servers = [];
  List<GameServer> get servers => List.unmodifiable(_servers);
  List<ServerFile> _files = [];
  List<ServerFile> get files => List.unmodifiable(_files);
  GameServer? selected;
  Map<String, dynamic> resources = {};
  String directory = '/', console = '', message = '';
  bool busy = false, initialized = false;
  bool get signedIn => repository.api.token != null;
  bool get demo => config['mode'] == 'demo';
  int get hours => (config['renewal_hours'] as num?)?.toInt() ?? 5;
  Timer? timer;
  bool disposed = false;

  void update() { if (!disposed) notifyListeners(); }
  Future<bool> run(Future<void> Function() action) async {
    if (busy) return false;
    busy = true; message = ''; update();
    try { await action(); return true; }
    catch (e) {
      if (e is ApiException && e.status == 401) {
        repository.api.token = null;
        if (!kIsWeb) await storage.delete(key: 'session');
        _servers = []; selected = null; wallet = {'balance': 0, 'history': [], 'orders': []}; purchaseKeys.clear();
      }
      message = e.toString().replaceFirst('Exception: ', ''); return false;
    } finally { busy = false; update(); }
  }
  Future<void> initialize() async {
    await run(() async {
      config = await repository.config();
      if (!kIsWeb) repository.api.token = await storage.read(key: 'session');
      if (signedIn) await loadServers();
    });
    initialized = true;
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (signedIn && !busy) run(() async { await loadServers(); if (selected != null) await loadDetail(); });
      else { update(); }
    });
    update();
  }
  Future<bool> login(String email, String password, String invite, bool register) => run(() async {
    await repository.signIn(email, password, invite, register);
    if (!kIsWeb) await storage.write(key: 'session', value: repository.api.token);
    await loadServers();
  });
  Future<void> loadServers() async {
    _servers = await repository.servers();
    await loadWallet();
    if (selected != null) {
      final same = _servers.where((s) => s.id == selected!.id);
      selected = same.isEmpty ? null : same.first;
    }
  }
  Future<void> loadDetail() async {
    final s = selected;
    if (s == null || s.status.startsWith('provisioning')) return;
    resources = await repository.resources(s.id);
    console = await repository.console(s.id);
  }
  Future<bool> select(GameServer s) => run(() async {
    selected = s; directory = '/'; _files = []; resources = {}; console = '';
    await loadDetail();
    if (!s.status.startsWith('provisioning')) _files = await repository.files(s.id, directory);
  });
  void back() { selected = null; message = ''; update(); }
  Future<bool> refresh() => run(() async { config = await repository.config(); await loadServers(); if (selected != null) { await loadDetail(); _files = await repository.files(selected!.id, directory); } });
  Future<bool> create(String name) => run(() async { await repository.create(name); await loadServers(); });
  Future<bool> power(String signal) => run(() async { await repository.power(selected!.id, signal); await loadServers(); await loadDetail(); });
  Future<bool> openDirectory(String path) => run(() async { final next = await repository.files(selected!.id, path); directory = path; _files = next; });
  Future<bool> command(String text) => run(() async { await repository.command(selected!.id, text); console = await repository.console(selected!.id); });
  Future<bool> write(String path, Uint8List bytes) => run(() async { await repository.write(selected!.id, path, bytes); _files = await repository.files(selected!.id, directory); });
  Future<bool> fileAction(String action, String path, [String target = '']) => run(() async { await repository.fileAction(selected!.id, action, path, target); _files = await repository.files(selected!.id, directory); });
  Future<void> loadWallet() async {
    wallet = await repository.wallet();
    products = await repository.catalog();
  }
  Future<bool> earnCoins() => run(() async {
    if (!demo && !rewards.available) throw Exception('Los anuncios están disponibles en la app móvil configurada.');
    final intent = await repository.intent();
    if (demo) {
      await repository.demoReward(intent['intent'] as String);
      message = 'Prueba completada: +${intent['coins']} monedas. No se mostró publicidad real.';
    } else {
      final earned = await rewards.show(intent['intent'] as String, intent['user_id'] as String);
      if (!earned) { message = 'No se completó el anuncio. Tu saldo no cambió.'; return; }
      var credited = false;
      for (var i = 0; i < 10; i++) {
        await Future<void>.delayed(const Duration(seconds: 2));
        if (await repository.rewardStatus(intent['intent'] as String)) { credited = true; break; }
      }
      message = credited ? 'Recompensa confirmada: +${intent['coins']} monedas.' : 'Esperando confirmación del proveedor. Tu saldo se actualizará automáticamente.';
    }
    await loadWallet();
  });
  Future<bool> buy(String serverId, String sku) => run(() async {
    final reference = '$serverId:$sku';
    final key = purchaseKeys.putIfAbsent(reference, () => List.generate(32, (_) => Random.secure().nextInt(16).toRadixString(16)).join());
    final result = await repository.purchase(serverId, sku, key);
    await loadServers();
    purchaseKeys.remove(reference);
    message = result['status'] == 'complete' ? 'Compra completada.' : 'Monedas reservadas. Tu ampliación está pendiente de confirmación; no vuelvas a comprarla.';
  });
  Future<bool> removeServer() => run(() async { await repository.deleteServer(selected!.id); selected = null; await loadServers(); });
  Future<bool> logout() => run(() async { await repository.logout(); if (!kIsWeb) await storage.delete(key: 'session'); _servers = []; selected = null; wallet = {'balance': 0, 'history': [], 'orders': []}; purchaseKeys.clear(); });
  Future<bool> removeAccount() => run(() async { await repository.deleteAccount(); if (!kIsWeb) await storage.delete(key: 'session'); _servers = []; selected = null; wallet = {'balance': 0, 'history': [], 'orders': []}; purchaseKeys.clear(); });
  @override void dispose() { disposed = true; timer?.cancel(); repository.api.close(); super.dispose(); }
}
