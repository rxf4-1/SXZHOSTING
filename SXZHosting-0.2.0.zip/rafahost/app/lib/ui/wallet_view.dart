import 'package:flutter/material.dart';
import 'hosting_model.dart';

void openWallet(BuildContext context, HostingModel model) {
  Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => WalletView(model: model)));
}

class WalletView extends StatefulWidget {
  const WalletView({super.key, required this.model});
  final HostingModel model;
  @override State<WalletView> createState() => _WalletViewState();
}
class _WalletViewState extends State<WalletView> {
  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) widget.model.run(widget.model.loadWallet); }); }
  @override Widget build(BuildContext context) => ListenableBuilder(listenable: widget.model, builder: (context, _) {
    final m = widget.model;
    final server = m.selected ?? (m.servers.isEmpty ? null : m.servers.first);
    final history = (m.wallet['history'] as List?) ?? [];
    final pending = ((m.wallet['orders'] as List?) ?? []).where((o) => o['status'] == 'pending').toList();
    return Scaffold(appBar: AppBar(title: const Text('Monedas y tienda')), body: ListView(padding: const EdgeInsets.all(24), children: [
      if (m.busy) const LinearProgressIndicator(),
      const SizedBox(height: 20), const Text('TU SALDO', style: TextStyle(letterSpacing: 2, color: Colors.white60)),
      Text('${m.balance} monedas', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12), Text('Gana ${m.adCoins} monedas por anuncio completado. Límite: ${m.config['daily_ads'] ?? 20} al día (UTC).'),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: m.busy || !m.signedIn ? null : () async {
        if (m.demo) {
          final accepted = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Simular recompensa'), content: Text('Esta prueba añade ${m.adCoins} monedas sin anuncios reales ni ingresos.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Probar'))]));
          if (accepted != true) return;
        }
        await m.earnCoins();
      }, icon: const Icon(Icons.play_circle_outline), label: Text(m.demo ? 'Probar anuncio · +${m.adCoins}' : 'Ver anuncio · +${m.adCoins} monedas')),
      if (m.message.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 18), child: Text(m.message, style: const TextStyle(color: Color(0xFFCFEC8D)))),
      if (pending.isNotEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Text('Hay una ampliación pendiente. Las monedas están reservadas y el servicio reintentará aplicarla.')),
      const SizedBox(height: 24), const Text('Mejora tu servidor', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8), Text(server == null ? 'Crea un servidor para comprar recursos. Puedes ganar monedas desde ahora.' : 'Compras para: ${server.name}'),
      const SizedBox(height: 16),
      for (final p in m.products) Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(p['kind'] == 'time' ? Icons.schedule : p['kind'] == 'memory' ? Icons.memory : p['kind'] == 'disk' ? Icons.storage : Icons.speed, color: const Color(0xFFCFEC8D)), const SizedBox(width: 12), Expanded(child: Text(p['title'] as String, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600)))]),
        const SizedBox(height: 10), Text(p['description'] as String, style: const TextStyle(color: Colors.white60)),
        const SizedBox(height: 16), FilledButton.tonal(onPressed: m.busy || !m.signedIn || server == null || p['enabled'] != true || m.balance < (p['cost'] as num) || pending.isNotEmpty ? null : () async {
          final accepted = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: Text('Comprar ${p['title']}'), content: Text('Se descontarán ${p['cost']} monedas de tu saldo para ${server.name}. ${p['description']}.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Comprar'))]));
          if (accepted == true) await m.buy(server.id, p['sku'] as String);
        }, child: Text(p['enabled'] != true ? 'No disponible' : 'Comprar · ${p['cost']} monedas')),
      ]))),
      const SizedBox(height: 24), const Text('Movimientos', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
      if (history.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 20), child: Text('Todavía no hay movimientos.')),
      for (final item in history) ListTile(contentPadding: EdgeInsets.zero, title: Text(item['reason'] as String), subtitle: Text(DateTime.fromMillisecondsSinceEpoch(((item['created'] as num) * 1000).round()).toLocal().toString().substring(0, 16)), trailing: Text('${(item['delta'] as num) > 0 ? '+' : ''}${item['delta']}', style: const TextStyle(fontSize: 18))),
      const SizedBox(height: 12), const Text('Las monedas se usan en este servicio. No tienen valor en efectivo ni se transfieren entre cuentas.', style: TextStyle(color: Colors.white60, fontSize: 12)),
    ]));
  });
}
