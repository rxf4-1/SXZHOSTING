#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir/backend"
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock.txt
export HOSTING_MODE=demo
exec .venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --workers 1
