# Monedas y recursos · 0.2

Registro obligatorio. Las monedas pertenecen a la cuenta; se pueden ganar antes de crear un servidor. No hay compra con dinero real ni transferencia de monedas.

## Configuración de AdMob iOS

- App ID: `ca-app-pub-9419517058946613~9936383467`.
- Unidad recompensada: `ca-app-pub-9419517058946613/5939841867`.
- En AdMob configura cantidad **10** y nombre exacto **Monedas**. Deben coincidir con `AD_REWARD_COINS=10` y `AD_REWARD_ITEM=Monedas` del backend.
- URL de verificación del servidor (SSV): `https://TU_DOMINIO/api/rewards/admob`.
- `.env.example` ya autoriza esa unidad en `ADMOB_AD_UNITS`.
- El cliente envía intención y usuario en SSV. Solo el callback firmado acredita monedas; cerrar el anuncio no es prueba de recompensa.
- Configura UMP y prueba en un dispositivo físico. Para publicidad real compila con `ADMOB_LIVE=true`; sin esa opción se usan unidades de prueba. La demo simula recompensas sin Google. Las unidades de prueba no acreditan automáticamente la cuenta de producción.

## Catálogo inicial configurable

| Producto | Monedas | Variable |
|---|---:|---|
| +5 horas | 10 | PRICE_TIME |
| +512 MB RAM | 40 | PRICE_RAM |
| +1024 MB disco | 30 | PRICE_DISK |
| +25 puntos de CPU | 30 | PRICE_CPU |

CPU usa la escala porcentual de Pterodactyl; 100 equivale al límite de un núcleo. No promete un núcleo dedicado. Las ampliaciones duran hasta eliminar el servidor; el tiempo caduca. El límite acumulable es 24 horas. Cambiar RAM puede requerir reiniciar Minecraft para que Java aplique su nuevo límite.

En modo real la tienda de recursos está deshabilitada hasta configurar `RESOURCE_SHOP_ENABLED=true` y presupuestos `SHOP_TOTAL_RAM_MB`, `SHOP_TOTAL_DISK_MB`, `SHOP_TOTAL_CPU`. Reserva capacidad para TODOS los servidores de la app, incluidas compras pendientes; estos presupuestos no detectan otros servicios de tu VPS. Límites por servidor: `MAX_SERVER_RAM_MB`, `MAX_SERVER_DISK_MB`, `MAX_SERVER_CPU`. Dimensiona el nodo antes de habilitarla. La clave Application necesita permiso de actualización de servidores.

Precios y recompensa son valores piloto. Calcula ingresos reales y costes antes de ofrecerlos públicamente; un RPM de 2–5 USD significa aproximadamente ese ingreso por mil impresiones, no por cada anuncio.

## Fallos y migración

Respalda SQLite antes de actualizar. Al arrancar se crean monederos y tablas de movimientos/compras; se conservan cuentas y servidores. Para servidores existentes la migración presupone límites de 1024 MB RAM, 2048 MB disco y CPU 100. Antes de habilitar compras reales compara y corrige esos valores con los límites actuales del panel.

Una compra pendiente reserva monedas y se reintenta cada 20 segundos con los mismos límites absolutos. No se cobra otra vez y se bloquea borrar el servidor mientras esté pendiente. Si el operador cambió los límites remotamente, se requiere conciliación manual: con el servicio detenido, compara el objetivo guardado en `orders.desired`, el panel y SQLite. No reembolses ni elimines una orden sin comprobar si el cambio ya se aplicó. Esta beta no incluye pantalla de soporte para resolver órdenes.
