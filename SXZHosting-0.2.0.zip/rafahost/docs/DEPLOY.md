# Instalación y conexión con Pterodactyl

## 1. Demo en una VPS

Con Docker Engine y Docker Compose instalados, extrae el proyecto y ejecuta:

```bash
cd rafahost
cp .env.example .env
chmod 600 .env
docker compose up -d --build
docker compose logs --tail=50 api
```

El backend queda escuchando solo en `127.0.0.1:8000`. Configura un dominio y HTTPS en el proxy de la VPS. `Caddyfile.example` contiene un ejemplo para Caddy. Conserva el volumen `hosting-data`: contiene cuentas, servidores y horas. No uses `docker compose down -v` si quieres mantener los datos.

Para acceder localmente a la VPS sin publicar todavía:

```bash
ssh -L 8000:127.0.0.1:8000 USUARIO@IP_DE_TU_VPS
```

Después abre http://localhost:8000 en la computadora desde la que ejecutaste SSH.

## 2. Infraestructura real

Instala **Panel Pterodactyl 1.x estable** y **Wings** siguiendo la documentación oficial. Esta app no instala ni reemplaza esos componentes.

- Panel: https://pterodactyl.io/panel/1.0/getting_started.html
- Wings: https://pterodactyl.io/wings/1.0/installing.html
- Proyecto: https://github.com/pterodactyl/panel

Prepara al menos un nodo, una ubicación, puertos/asignaciones libres y un egg de Minecraft Java probado. Ejecuta manualmente un servidor de prueba en el panel antes de conectar la app. El firewall debe permitir los puertos del juego y la comunicación requerida por Wings.

Crea un **usuario de servicio dedicado** de Pterodactyl. Todos los servidores creados por esta app tendrán ese propietario. Genera una **Client API key** de ese usuario, con acceso a esos servidores, y una **Application API key** con permisos para crear, suspender, reactivar y eliminar servidores. La autorización por cuenta de RafaHost ocurre en nuestro backend. Las cuentas finales no reciben acceso directo al usuario de servicio.

En `.env`:

```dotenv
HOSTING_MODE=pterodactyl
PTERO_URL=https://panel.tudominio.com
PTERO_APPLICATION_KEY=CLAVE_DE_APPLICATION
PTERO_CLIENT_KEY=CLAVE_DEL_USUARIO_DE_SERVICIO
PTERO_OWNER_ID=ID_NUMERICO_DEL_USUARIO_DE_SERVICIO
REGISTRATION_CODE=CODIGO_LARGO_PARA_TUS_PROBADORES
CORS_ORIGINS=https://hosting.tudominio.com
MAX_SERVERS=10
```

Configura `PTERO_TEMPLATE_JSON` con IDs reales de egg y ubicación y los campos requeridos por ese egg. La plantilla de ejemplo no conoce tus IDs. Ajusta imagen Java, memoria, CPU, disco, variables del egg y comando de inicio. `name`, `user`, `external_id` y `start_on_completion` son controlados por el backend. Los clientes no eligen cuotas ni asignaciones.

La reserva se crea antes de llamar al panel. Si el panel falla o el resultado es incierto, se mantiene como `provisioning_error` y ocupa el cupo. Antes de eliminar o modificar esa reserva, el operador debe buscar en Pterodactyl el `external_id` que coincide con el UUID de RafaHost, verificar si el servidor se creó y vincularlo o eliminarlo según corresponda. Esto evita crear servidores duplicados por un timeout. La primera versión no incluye una pantalla de operador para esa conciliación.

La plantilla debe producir un servidor con EULA aceptado únicamente después de la confirmación del usuario, según el mecanismo del egg elegido. El modo demo crea `eula=true`; en modo real comprueba el comportamiento de tu egg y, si hace falta, configura esa variable o el archivo desde el panel antes de iniciar. No configures un egg de otro juego pensando que la app lo detectará: esta versión es para Minecraft Java.

## 3. Renovación con AdMob

1. Configura las aplicaciones iOS/Android y sus unidades **recompensadas** en AdMob.
2. Configura el mensaje de privacidad/consentimiento UMP correspondiente.
3. En cada unidad, configura la URL SSV: `https://hosting.tudominio.com/api/rewards/admob`.
4. Incluye los IDs exactos en `ADMOB_AD_UNITS` separados por comas, sin espacios.
5. Sigue `MONEDAS.md`: recompensa exacta 10 `Monedas`, IDs iOS incorporados y activación explícita `ADMOB_LIVE=true`.
6. Verifica en un dispositivo que cerrar un anuncio antes de completarlo no añade monedas; completarlo solo añade monedas después del callback firmado. Verifica también repetición de callback, pérdida de red y falta de anuncios.

El backend verifica bytes originales, firma ECDSA, clave pública de Google, unidad autorizada, antigüedad, usuario e intención. Una transacción se acredita una sola vez. Los callbacks de la última hora se aceptan si la intención continúa válida. El crédito se guarda antes de reactivar: si Pterodactyl está caído, el trabajador reintenta. Una demora de confirmación no debe llevar al usuario a pulsar repetidamente.

El modo demo tiene una ruta separada para simular recompensas; esa ruta responde 404 en modo real. No habilites el modo demo en una instalación que pretenda otorgar recursos reales: este modo nunca ejecuta Pterodactyl.

Fuentes de integración:
- https://developers.google.com/admob/flutter/rewarded
- https://developers.google.com/admob/flutter/ssv

## 4. Operación

Ejecuta **una sola instancia / worker** del backend en esta beta. La serialización de mutaciones vive en ese proceso y SQLite almacena los datos. Antes de escalar a varios procesos, migra a una base de datos compartida y a trabajos/locks distribuidos.

Mantén el backend activo: el vencimiento se revisa cada 20 segundos mientras el proceso funciona. Si la API o el panel permanecen caídos, la suspensión puede retrasarse. Monitoriza salud, reinicios y conciliaciones pendientes. La app no elimina mundos al vencer y no apaga automáticamente por falta de jugadores.

Respalda la base de datos con el comando `sqlite3 ... '.backup ...'` o una copia coherente con el servicio detenido. Copia los archivos del juego mediante Pterodactyl o el procedimiento de respaldo de Wings. Una copia de la base SQLite no contiene los mundos de servidores reales.

No se promete compatibilidad con Pterodactyl 2.x: el adaptador está dirigido a rutas 1.x. Ejecuta una prueba real de creación, archivos, consola, expiración, renovación y borrado antes de admitir jugadores.
