# Decisiones de implementación

La app Flutter separa servicios HTTP, repositorio, modelos y ViewModel (`ChangeNotifier`). Las vistas reciben el ViewModel y los datos, y el backend decide cuotas, propiedad y recompensas. Se aplicaron las instrucciones instaladas de arquitectura y HTTP de `flutter/skills`.

La app nunca contiene claves administrativas. Las cuentas RafaHost y las sesiones opacas son propias; el operador configura una cuenta de servicio Pterodactyl que posee los servidores remotos. Cada ruta consulta la pareja usuario/servidor antes de llamar al panel. El cliente no envía IDs de asignaciones, límites ni IDs remotos.

La API Application crea/suspende/elimina. La API Client de la cuenta de servicio administra potencia, comandos y archivos. Los datos se guardan en SQLite en esta primera versión; requiere un solo proceso de API. La plantilla del egg vive en el entorno del backend, controlada por el operador.

La interfaz web del paquete es un cliente auxiliar para probar la API. La aplicación móvil se implementa por separado en Flutter. Ambos usan las mismas rutas y la misma autorización.

Una intención de anuncio une cuenta, cantidad y tipo de recompensa durante una hora. El callback firmado acredita el monedero y el libro de movimientos en una transacción SQLite. Comprar tiempo descuenta saldo y actualiza vencimiento atómicamente. Comprar recursos reserva saldo y capacidad antes de aplicar un objetivo absoluto en Pterodactyl. Un timeout deja la compra pendiente y el trabajador reintenta ese mismo objetivo, sin incrementar otra vez. Se conservan las intenciones anteriores de renovación durante la migración.

Los datos de la cuenta incluyen correo, hash de contraseña, sesiones y vencimiento inicial. Los servidores conservan identificadores remotos y vencimiento. Las recompensas guardan identificador de transacción e intención para impedir duplicados; al borrar la cuenta no contienen su correo. Decide y documenta una política de retención operativa antes de producción.

Pendientes de siguiente fase: correo verificado/recuperación, operador para conciliar aprovisionamiento, webhooks de estado, cuotas distribuidas, copias de seguridad y planes pagados. No se incluyen como botones ficticios en la interfaz.
