# Verificación de la entrega 0.2.0

## Ejecutado

- **17 pruebas pytest del backend aprobadas** en modo demo, con bases SQLite temporales.
- Inicio de sesión, cierre y revocación; persistencia al volver a entrar.
- Aislamiento de cuentas para consultas, archivos y controles.
- Escritura/lectura, renombrado de carpeta con sus archivos, borrado, rechazo de rutas `..` y del borrado de raíz, límites de tamaño.
- Vencimiento, bloqueo de encendido, suspensión, renovación y reactivación.
- Reintento de una recompensa sin duplicar monedas; una cuenta no usa la intención de otra.
- Verificación ECDSA con claves de prueba: firma correcta aceptada; texto alterado, unidad incorrecta y parámetros añadidos rechazados.
- La ruta de recompensa demo queda bloqueada en modo real.
- Fallo de aprovisionamiento conserva la reserva y evita duplicados.
- Recrear un servidor no reinicia el plazo de prueba gratuito.
- **Prueba DOM + API aprobada**: registro, creación, encendido, edición y reapertura de archivo, carpeta nueva, anuncio simulado, crédito de monedas, compra de tiempo, eliminación de servidor y cuenta. Sin errores JavaScript no capturados. Usa jsdom y el backend real de demostración, no un simulador de API.
- Sintaxis JavaScript, sintaxis Python y scripts Bash comprobadas.
- Los archivos Dart pasan un parser sintáctico Tree-sitter. Esto no sustituye `flutter analyze`, tests Flutter ni compilación.
- Se comprobaron las firmas de `setServerSideOptions`, `showPrivacyOptionsForm` y `saveFile` en los paquetes utilizados.

## Pendiente / bloqueado

- Preparación del SDK Flutter: la revisión automática la rechazó por un acceso inesperado al servicio de metadatos de la máquina. No se intentó eludir el bloqueo. No se ejecutaron `flutter analyze`, `flutter test` ni builds. El workflow y los tests se incluyen para ejecutarlos en un entorno autorizado.
- Prueba visual en Chromium: el navegador no estaba instalado y las descargas devolvieron archivos inválidos. La prueba DOM verifica interacción y lógica, no composición visual, tamaños, accesibilidad ni desbordamiento en pantallas reales.
- Prueba contra Pterodactyl/Wings reales: no hay infraestructura ni claves proporcionadas. El adaptador usa rutas 1.x contrastadas con el código oficial, pero necesita una prueba integral con tu egg y nodo.
- AdMob real: los IDs iOS están incorporados; faltan configuración remota SSV y prueba en dispositivo. Las pruebas criptográficas no sustituyen una prueba de callback de Google ni un anuncio en dispositivo físico.
- No hay IPA, firma Apple, subida a TestFlight, publicación ni ingresos generados.

## Repetir pruebas del panel

Con Node.js 24 y el entorno Python del backend preparado:

```bash
cd tests/web
npm ci
../../backend/.venv/bin/python run.py
```

La prueba levanta una API local en el puerto 8001 y utiliza una base temporal; deja el puerto libre antes de ejecutarla. No requiere descargar Chromium.

## Nuevas comprobaciones 0.2

Saldo e historial, acreditación antes de crear servidor, doble callback, importe/nombre de recompensa, aislamiento de cuentas, claves de compra idempotentes, saldo insuficiente, compras concurrentes, límites globales y por servidor, límite diario, reintento tras timeout y migración desde 0.1: aprobados en pytest. La integración de ampliación con un nodo real permanece pendiente.
