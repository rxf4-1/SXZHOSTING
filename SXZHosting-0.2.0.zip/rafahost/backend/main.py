import asyncio
import hashlib
import hmac
import os
import secrets
import sqlite3
import time
import uuid
from contextlib import asynccontextmanager, suppress
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, Depends, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
import core
from core import db, rate_limit
from provider import DemoProvider, PterodactylProvider, clean_path
import rewards
import shop

provider=None
mutation=asyncio.Lock()

def owned(sid,uid):
    with db() as c: r=c.execute('SELECT * FROM servers WHERE id=? AND user_id=?',(sid,uid)).fetchone()
    if not r: raise HTTPException(404,'Servidor no encontrado.')
    return dict(r)

def usable(s):
    if s['status'] in ('provisioning','provisioning_error'): raise HTTPException(409,'La instalación requiere revisión del administrador.')

def public(s): return {k:s[k] for k in ('id','name','status','expires','created','memory','disk','cpu')}

async def reconcile():
    async with mutation:
        await shop.process_pending(provider)
        with db() as c: rows=c.execute("SELECT * FROM servers WHERE status NOT IN ('provisioning','provisioning_error')").fetchall()
        for row in rows:
            s=dict(row)
            expired=s['expires']<=time.time()
            if (expired and s['status']!='suspended') or (not expired and s['status']=='suspended'):
                try:
                    await provider.suspend(s,expired)
                    with db() as c: c.execute('UPDATE servers SET status=? WHERE id=?',('suspended' if expired else 'offline',s['id']))
                except Exception:
                    import logging
                    logging.getLogger('rafahost').warning('Reconciliation pending for server %s',s['id'])

async def worker():
    while True:
        await reconcile()
        await asyncio.sleep(20)

@asynccontextmanager
async def lifespan(app):
    global provider
    if core.MODE not in ('demo','pterodactyl'): raise RuntimeError('HOSTING_MODE no válido')
    if core.MODE=='pterodactyl' and not os.getenv('REGISTRATION_CODE'): raise RuntimeError('Configura REGISTRATION_CODE para la beta privada')
    core.init_db()
    provider=DemoProvider() if core.MODE=='demo' else PterodactylProvider()
    task=asyncio.create_task(worker())
    yield
    task.cancel()
    with suppress(asyncio.CancelledError): await task

app=FastAPI(title='RafaHost API',version='0.2.0',lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=os.getenv('CORS_ORIGINS','http://localhost:8080,http://127.0.0.1:8080').split(','),allow_methods=['GET','POST','PUT','DELETE'],allow_headers=['Authorization','Content-Type'])

@app.middleware('http')
async def guard(request,call_next):
    try:
        if int(request.headers.get('content-length','0'))>core.MAX_BYTES+1024: return Response(status_code=413)
    except ValueError: return Response(status_code=400)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    if request.url.path.startswith('/api'): response.headers['Cache-Control']='no-store'
    return response

def auth(request:Request):
    value=request.headers.get('authorization','')
    if not value.startswith('Bearer '): raise HTTPException(401,'Inicia sesión.')
    digest=hashlib.sha256(value[7:].encode()).hexdigest()
    with db() as c: r=c.execute('SELECT user_id FROM sessions WHERE token=? AND expires>?',(digest,time.time())).fetchone()
    if not r: raise HTTPException(401,'Tu sesión venció. Inicia sesión de nuevo.')
    rate_limit('api:'+r['user_id'],240,60)
    return r['user_id']

class Credentials(BaseModel):
    email:str=Field(min_length=5,max_length=254,pattern=r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
    password:str=Field(min_length=10,max_length=128)
    invite:str=Field(default='',max_length=128)

def hash_password(password,salt=None):
    salt=salt or secrets.token_hex(16)
    return salt+':'+hashlib.scrypt(password.encode(),salt=salt.encode(),n=16384,r=8,p=1).hex()

def session(uid):
    token=secrets.token_urlsafe(40)
    with db() as c:
        c.execute('DELETE FROM sessions WHERE expires<?',(time.time(),))
        c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),uid,time.time()+7*86400))
    return {'token':token,'user_id':uid}

@app.get('/api/config')
def config(): return {'mode':core.MODE,'renewal_hours':core.HOURS,'max_hours':core.MAX_HOURS,'registration_invite':core.MODE!='demo','ads_enabled':bool(os.getenv('ADMOB_AD_UNITS')),'max_file_bytes':core.MAX_BYTES,'ad_coins':core.AD_COINS,'reward_item':core.AD_ITEM,'daily_ads':core.DAILY_ADS,'resource_shop':shop.resources_enabled(),'version':'0.2.0'}
@app.get('/api/health')
def health(): return {'ok':True,'mode':core.MODE}

@app.post('/api/auth/register')
def register(data:Credentials,request:Request):
    rate_limit('register:'+request.client.host,10,3600)
    if core.MODE!='demo' and not hmac.compare_digest(data.invite,os.getenv('REGISTRATION_CODE','')): raise HTTPException(403,'Código de invitación no válido.')
    uid=uuid.uuid4().hex
    try:
        with db() as c: c.execute('INSERT INTO users(id,email,password) VALUES(?,?,?)',(uid,data.email.strip().lower(),hash_password(data.password)))
    except sqlite3.IntegrityError: raise HTTPException(409,'No se pudo registrar este correo. Prueba iniciar sesión.')
    return session(uid)

@app.post('/api/auth/login')
def login(data:Credentials,request:Request):
    rate_limit('login:'+request.client.host,20,900)
    with db() as c: row=c.execute('SELECT * FROM users WHERE email=?',(data.email.strip().lower(),)).fetchone()
    stored=row['password'] if row else hash_password('dummy-password')
    valid=hmac.compare_digest(stored,hash_password(data.password,stored.split(':')[0]))
    if not row or not valid: raise HTTPException(401,'Correo o contraseña incorrectos.')
    return session(row['id'])

@app.post('/api/auth/logout')
def logout(request:Request,uid=Depends(auth)):
    digest=hashlib.sha256(request.headers['authorization'][7:].encode()).hexdigest()
    with db() as c: c.execute('DELETE FROM sessions WHERE token=?',(digest,))
    return {'ok':True}

@app.get('/api/servers')
def servers(uid=Depends(auth)):
    with db() as c: rows=c.execute('SELECT * FROM servers WHERE user_id=? ORDER BY created DESC',(uid,)).fetchall()
    return [public(r) for r in rows]

class NewServer(BaseModel):
    name:str=Field(min_length=2,max_length=32,pattern=r'^[\w .-]+$')
    accept_eula:bool

@app.post('/api/servers',status_code=201)
async def create(data:NewServer,uid=Depends(auth)):
    if not data.accept_eula: raise HTTPException(400,'Acepta el EULA de Minecraft para continuar.')
    async with mutation:
        with db() as c:
            if c.execute('SELECT count(*) FROM servers WHERE user_id=?',(uid,)).fetchone()[0]>=1: raise HTTPException(409,'El plan gratuito permite un servidor por cuenta.')
            if c.execute('SELECT count(*) FROM servers').fetchone()[0]>=core.CAPACITY: raise HTTPException(409,'No quedan cupos por el momento.')
            limits=core.base_limits()
            if shop.resources_enabled(): shop.check_capacity(c,limits)
            sid=uuid.uuid4().hex
            initial=c.execute('SELECT trial_expires FROM users WHERE id=?',(uid,)).fetchone()[0]
            if initial is None:
                initial=time.time()+core.HOURS*3600
                c.execute('UPDATE users SET trial_expires=? WHERE id=?',(initial,uid))
            c.execute('INSERT INTO servers(id,user_id,name,external_id,identifier,status,expires,created,memory,disk,cpu) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(sid,uid,data.name,None,None,'provisioning',initial,time.time(),limits['memory'],limits['disk'],limits['cpu']))
        try:
            remote=await provider.create(sid,data.name)
            with db() as c: c.execute("UPDATE servers SET external_id=?,identifier=?,status='offline' WHERE id=?",(remote['external_id'],remote['identifier'],sid))
        except Exception:
            with db() as c: c.execute("UPDATE servers SET status='provisioning_error' WHERE id=?",(sid,))
            raise HTTPException(502,'No se confirmó la instalación. El administrador debe revisar la reserva antes de reintentar.')
        return public(owned(sid,uid))

@app.get('/api/servers/{sid}/resources')
async def resources(sid:str,uid=Depends(auth)):
    s=owned(sid,uid); usable(s)
    return await provider.resources(s)

class Power(BaseModel): signal:Literal['start','stop','restart']
@app.post('/api/servers/{sid}/power')
async def power(sid:str,data:Power,uid=Depends(auth)):
    async with mutation:
        s=owned(sid,uid); usable(s)
        if data.signal!='stop' and s['expires']<=time.time(): raise HTTPException(403,'Renueva el tiempo antes de encender el servidor.')
        if s['status']=='suspended' and s['expires']>time.time():
            await provider.suspend(s,False)
            with db() as c: c.execute("UPDATE servers SET status='offline' WHERE id=?",(sid,))
        await provider.power(s,data.signal)
    return {'ok':True}

@app.get('/api/servers/{sid}/files')
async def files(sid:str,path:str='/',uid=Depends(auth)):
    s=owned(sid,uid); usable(s)
    return await provider.listing(s,clean_path(path))
@app.get('/api/servers/{sid}/file')
async def read_file(sid:str,path:str,uid=Depends(auth)):
    s=owned(sid,uid); usable(s)
    return Response(await provider.read(s,clean_path(path,False)),media_type='application/octet-stream')
@app.put('/api/servers/{sid}/file')
async def write_file(sid:str,path:str,request:Request,uid=Depends(auth)):
    s=owned(sid,uid); usable(s)
    path=clean_path(path,False)
    data=bytearray()
    async for chunk in request.stream():
        data.extend(chunk)
        if len(data)>core.MAX_BYTES: raise HTTPException(413,'El límite por archivo es de 5 MB.')
    await provider.write(s,path,bytes(data))
    return {'ok':True}

class FileOperation(BaseModel):
    action:Literal['mkdir','rename','delete']
    path:str=Field(max_length=512)
    target:str=Field(default='',max_length=512)
@app.post('/api/servers/{sid}/files')
async def file_operation(sid:str,data:FileOperation,uid=Depends(auth)):
    s=owned(sid,uid); usable(s)
    path=clean_path(data.path,False)
    if data.action=='mkdir': await provider.mkdir(s,path)
    elif data.action=='rename': await provider.rename(s,path,clean_path(data.target,False))
    else: await provider.delete_file(s,path)
    return {'ok':True}

class Command(BaseModel): command:str=Field(min_length=1,max_length=500,pattern=r'^[^\r\n\x00]+$')
@app.post('/api/servers/{sid}/command')
async def command(sid:str,data:Command,uid=Depends(auth)):
    s=owned(sid,uid); usable(s)
    if s['expires']<=time.time(): raise HTTPException(403,'Renueva el servidor para enviar comandos.')
    await provider.command(s,data.command)
    return {'ok':True}
@app.get('/api/servers/{sid}/console')
async def console(sid:str,uid=Depends(auth)):
    s=owned(sid,uid); usable(s)
    return {'text':await provider.console(s)}
@app.delete('/api/servers/{sid}')
async def delete(sid:str,uid=Depends(auth)):
    async with mutation:
        s=owned(sid,uid); usable(s)
        with db() as c:
            if c.execute("SELECT 1 FROM orders WHERE server_id=? AND status='pending'",(sid,)).fetchone(): raise HTTPException(409,'Espera a que termine la compra pendiente antes de eliminar el servidor.')
        await provider.delete(s)
        with db() as c: c.execute('DELETE FROM servers WHERE id=?',(sid,))
    return {'ok':True}

@app.post('/api/servers/{sid}/reward-intent')
def legacy_reward_intent(sid:str,uid=Depends(auth)):
    raise HTTPException(410,'Actualiza la app: los anuncios ahora añaden monedas al monedero.')

@app.get('/api/wallet')
def wallet(uid=Depends(auth)): return shop.get_wallet(uid)

@app.get('/api/wallet/reward-status/{intent_id}')
def reward_status(intent_id:str,uid=Depends(auth)):
    with db() as c: intent=c.execute('SELECT * FROM intents WHERE id=? AND user_id=?',(intent_id,uid)).fetchone()
    if not intent: raise HTTPException(404,'Recompensa no encontrada.')
    return {'credited':bool(intent['consumed']),'expired':intent['expires']<time.time()}

@app.get('/api/shop')
def products(uid=Depends(auth)): return shop.catalog()

@app.post('/api/wallet/reward-intent')
def reward_intent(uid=Depends(auth)):
    if core.MODE!='demo' and not os.getenv('ADMOB_AD_UNITS'): raise HTTPException(503,'Los anuncios todavía no están configurados.')
    rate_limit('reward:'+uid,30,3600)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        active=c.execute("SELECT * FROM intents WHERE user_id=? AND consumed=0 AND expires>? AND reward_kind='coins'",(uid,time.time())).fetchone()
        if active: return {'intent':active['id'],'user_id':uid,'coins':active['coins'],'item':active['reward_item']}
        today=(int(time.time())//86400)*86400
        count=c.execute("SELECT count(*) FROM ledger WHERE user_id=? AND reason='Anuncio completado' AND created>=?",(uid,today)).fetchone()[0]
        if count>=core.DAILY_ADS: raise HTTPException(429,'Alcanzaste el límite diario de anuncios. Vuelve mañana.')
        token=secrets.token_urlsafe(32)
        c.execute("INSERT INTO intents(id,server_id,user_id,expires,reward_kind,coins,reward_item) VALUES(?,NULL,?,?,'coins',?,?)",(token,uid,time.time()+3600,core.AD_COINS,core.AD_ITEM))
    return {'intent':token,'user_id':uid,'coins':core.AD_COINS,'item':core.AD_ITEM}

class Purchase(BaseModel):
    server_id:str
    sku:str
    idempotency_key:str=Field(min_length=16,max_length=100,pattern=r'^[a-zA-Z0-9_-]+$')

@app.post('/api/shop/purchase')
async def purchase(data:Purchase,uid=Depends(auth)):
    async with mutation:
        result=shop.purchase(uid,data.server_id,data.sku,data.idempotency_key)
        if result['status']=='pending': await shop.process_pending(provider,result['id'])
        with db() as c: result=dict(c.execute('SELECT * FROM orders WHERE id=?',(result['id'],)).fetchone())
    await reconcile()
    return {'order_id':result['id'],'status':result['status'],'cost':result['cost'],'wallet':shop.get_wallet(uid)}

def grant(intent_id,uid,transaction_id,amount=None,item=None):
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        if c.execute('SELECT 1 FROM rewards WHERE transaction_id=?',(transaction_id,)).fetchone(): return
        intent=c.execute('SELECT * FROM intents WHERE id=?',(intent_id,)).fetchone()
        if not intent or intent['user_id']!=uid or intent['expires']<time.time() or intent['consumed']: raise HTTPException(400,'Recompensa no válida o ya utilizada.')
        if not c.execute('SELECT 1 FROM users WHERE id=?',(uid,)).fetchone(): raise HTTPException(400,'Cuenta no disponible.')
        if intent['reward_kind']=='coins':
            if core.MODE!='demo' and (amount!=str(intent['coins']) or item!=intent['reward_item']): raise HTTPException(400,'La recompensa no coincide con la configuración.')
            c.execute('INSERT OR IGNORE INTO wallets(user_id) VALUES(?)',(uid,))
            c.execute('UPDATE wallets SET balance=balance+? WHERE user_id=?',(intent['coins'],uid))
            c.execute('INSERT INTO ledger(user_id,delta,reason,event_id,created) VALUES(?,?,?,?,?)',(uid,intent['coins'],'Anuncio completado','ad:'+transaction_id,time.time()))
        else:
            # Honor already-issued 0.1 intents; never silently change their reward.
            server=c.execute('SELECT * FROM servers WHERE id=?',(intent['server_id'],)).fetchone()
            if not server: raise HTTPException(404,'Servidor no encontrado.')
            expires=min(max(server['expires'],time.time())+core.HOURS*3600,time.time()+core.MAX_HOURS*3600)
            c.execute('UPDATE servers SET expires=? WHERE id=?',(expires,server['id']))
        c.execute('UPDATE intents SET consumed=1 WHERE id=?',(intent_id,))
        c.execute('INSERT INTO rewards VALUES(?,?,?)',(transaction_id,intent_id,time.time()))

class DemoReward(BaseModel): intent:str
@app.post('/api/rewards/demo')
async def demo_reward(data:DemoReward,uid=Depends(auth)):
    if core.MODE!='demo': raise HTTPException(404,'No encontrado.')
    grant(data.intent,uid,'demo:'+data.intent)
    await reconcile()
    return {'ok':True}
@app.get('/api/rewards/admob')
async def admob(request:Request):
    if core.MODE=='demo': raise HTTPException(404,'No encontrado.')
    p=await rewards.verify(request.scope['query_string'],set(filter(None,os.getenv('ADMOB_AD_UNITS','').split(','))))
    grant(p['custom_data'],p['user_id'],p['transaction_id'],p.get('reward_amount'),p.get('reward_item'))
    return {'ok':True}
@app.delete('/api/account')
async def delete_account(uid=Depends(auth)):
    async with mutation:
        with db() as c:
            if c.execute('SELECT 1 FROM servers WHERE user_id=?',(uid,)).fetchone(): raise HTTPException(409,'Elimina tu servidor antes de borrar la cuenta.')
            c.execute('DELETE FROM intents WHERE user_id=?',(uid,))
            c.execute('DELETE FROM sessions WHERE user_id=?',(uid,))
            c.execute('DELETE FROM users WHERE id=?',(uid,))
    return {'ok':True}

web=Path(__file__).parent/'web'
if web.exists(): app.mount('/',StaticFiles(directory=web,html=True),name='web')
