"""Atomic wallet debits and durable, idempotent resource orders."""
import json
import os
import time
import uuid
from fastapi import HTTPException
import core
from core import db


def resources_enabled():
    return core.MODE=='demo' or (os.getenv('RESOURCE_SHOP_ENABLED')=='true' and all(os.getenv(k) for k in ('SHOP_TOTAL_RAM_MB','SHOP_TOTAL_DISK_MB','SHOP_TOTAL_CPU')))


def catalog():
    # Prices are configurable pilot values, not an income/cost prediction.
    return [
        {'sku':'time_5h','title':f'+{core.HOURS} horas','description':'Tiempo para tu servidor','cost':int(os.getenv('PRICE_TIME','10')),'kind':'time','amount':core.HOURS,'enabled':True},
        {'sku':'ram_512','title':'+512 MB RAM','description':'Hasta eliminar este servidor; reinicio manual para aplicar al juego','cost':int(os.getenv('PRICE_RAM','40')),'kind':'memory','amount':512,'enabled':resources_enabled()},
        {'sku':'disk_1024','title':'+1 GB de disco','description':'Hasta eliminar este servidor','cost':int(os.getenv('PRICE_DISK','30')),'kind':'disk','amount':1024,'enabled':resources_enabled()},
        {'sku':'cpu_25','title':'+25% de CPU','description':'Cuota adicional; hasta eliminar este servidor','cost':int(os.getenv('PRICE_CPU','30')),'kind':'cpu','amount':25,'enabled':resources_enabled()},
    ]


def get_wallet(uid):
    with db() as c:
        c.execute('INSERT OR IGNORE INTO wallets(user_id) VALUES(?)',(uid,))
        balance=c.execute('SELECT balance FROM wallets WHERE user_id=?',(uid,)).fetchone()[0]
        history=c.execute('SELECT delta,reason,created FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 50',(uid,)).fetchall()
        orders=c.execute('SELECT id,server_id,sku,cost,status,created FROM orders WHERE user_id=? ORDER BY created DESC LIMIT 20',(uid,)).fetchall()
    return {'balance':balance,'history':[dict(r) for r in history],'orders':[dict(r) for r in orders]}


def check_capacity(c, extra):
    totals={k:c.execute('SELECT COALESCE(sum('+k+'),0) FROM servers').fetchone()[0] for k in ('memory','disk','cpu')}
    for row in c.execute("SELECT o.desired,s.memory,s.disk,s.cpu FROM orders o JOIN servers s ON s.id=o.server_id WHERE o.status='pending'"):
        desired=json.loads(row['desired'])
        for k in totals: totals[k]+=desired[k]-row[k]
    limits={'memory':int(os.getenv('SHOP_TOTAL_RAM_MB') or '16384'),'disk':int(os.getenv('SHOP_TOTAL_DISK_MB') or '65536'),'cpu':int(os.getenv('SHOP_TOTAL_CPU') or '1600')}
    for k in totals:
        if totals[k]+extra.get(k,0)>limits[k]: raise HTTPException(409,'No hay capacidad disponible para estos recursos. No se descontaron monedas.')


def purchase(uid,sid,sku,key):
    product=next((p for p in catalog() if p['sku']==sku),None)
    if not product: raise HTTPException(404,'Producto no encontrado.')
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        previous=c.execute('SELECT * FROM orders WHERE user_id=? AND idempotency_key=?',(uid,key)).fetchone()
        if previous:
            if previous['server_id']!=sid or previous['sku']!=sku: raise HTTPException(409,'La solicitud ya se usó para otra compra.')
            return dict(previous)
        s=c.execute('SELECT * FROM servers WHERE id=? AND user_id=?',(sid,uid)).fetchone()
        if not s: raise HTTPException(404,'Servidor no encontrado.')
        if s['status'].startswith('provisioning'): raise HTTPException(409,'Espera a que termine la instalación.')
        if not product['enabled']: raise HTTPException(409,'La tienda de recursos no está habilitada por el operador.')
        if product['cost']<=0: raise HTTPException(503,'Precio no configurado.')
        if c.execute("SELECT 1 FROM orders WHERE server_id=? AND status='pending'",(sid,)).fetchone(): raise HTTPException(409,'Hay una compra pendiente para este servidor. No se descontaron monedas adicionales.')
        desired={k:s[k] for k in ('memory','disk','cpu')}
        expires=None
        if product['kind']=='time':
            expires=max(s['expires'],time.time())+core.HOURS*3600
            if expires>time.time()+core.MAX_HOURS*3600+1: raise HTTPException(409,'La compra superaría el máximo de horas. No se descontaron monedas.')
        else:
            kind=product['kind']
            desired[kind]+=product['amount']
            cap={'memory':int(os.getenv('MAX_SERVER_RAM_MB','4096')),'disk':int(os.getenv('MAX_SERVER_DISK_MB','8192')),'cpu':int(os.getenv('MAX_SERVER_CPU','200'))}[kind]
            if desired[kind]>cap: raise HTTPException(409,'Este servidor alcanzó el límite de ese recurso.')
            check_capacity(c,{kind:product['amount']})
        c.execute('INSERT OR IGNORE INTO wallets(user_id) VALUES(?)',(uid,))
        if c.execute('UPDATE wallets SET balance=balance-? WHERE user_id=? AND balance>=?',(product['cost'],uid,product['cost'])).rowcount!=1: raise HTTPException(409,'No tienes suficientes monedas.')
        order_id=uuid.uuid4().hex
        status='complete' if expires else 'pending'
        c.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?)',(order_id,uid,sid,sku,product['cost'],status,json.dumps(desired),key,time.time()))
        c.execute('INSERT INTO ledger(user_id,delta,reason,event_id,created) VALUES(?,?,?,?,?)',(uid,-product['cost'],product['title'],'order:'+order_id,time.time()))
        if expires: c.execute('UPDATE servers SET expires=? WHERE id=?',(expires,sid))
        return dict(c.execute('SELECT * FROM orders WHERE id=?',(order_id,)).fetchone())


async def process_pending(provider, order_id=None):
    # Caller holds main.mutation: don't apply an old target over a newer upgrade.
    with db() as c:
        query="SELECT * FROM orders WHERE status='pending'"
        rows=c.execute(query+(' AND id=?' if order_id else ''),(order_id,) if order_id else ()).fetchall()
    for row in rows:
        with db() as c: server=c.execute('SELECT * FROM servers WHERE id=?',(row['server_id'],)).fetchone()
        if not server: continue
        desired=json.loads(row['desired'])
        try: await provider.set_limits(dict(server),desired)
        except Exception:
            # Timeout may mean remote apply succeeded. Keep the durable reservation;
            # retry the same absolute limits rather than incrementing or refunding.
            continue
        with db() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute('UPDATE servers SET memory=?,disk=?,cpu=? WHERE id=?',(desired['memory'],desired['disk'],desired['cpu'],server['id']))
            c.execute("UPDATE orders SET status='complete' WHERE id=?",(row['id'],))
