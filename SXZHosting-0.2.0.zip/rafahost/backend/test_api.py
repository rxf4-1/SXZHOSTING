import asyncio
import base64
import time
from urllib.parse import urlencode
import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes
import core
import main
import rewards

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(core,'DB_PATH',str(tmp_path/'db.sqlite'))
    monkeypatch.setattr(core,'MODE','demo')
    main.mutation=asyncio.Lock()
    with TestClient(main.app) as c: yield c

def user(c,email='one@example.com'):
    r=c.post('/api/auth/register',json={'email':email,'password':'testpassword123'})
    assert r.status_code==200,r.text
    return {'Authorization':'Bearer '+r.json()['token']}

def server(c,h):
    r=c.post('/api/servers',headers=h,json={'name':'My World','accept_eula':True})
    assert r.status_code==201,r.text
    return r.json()['id']

def test_auth_files_and_isolation(client):
    c=client; a=user(c); b=user(c,'two@example.com'); sid=server(c,a)
    assert c.get('/api/servers').status_code==401
    for endpoint in ('resources','files','console'):
        assert c.get(f'/api/servers/{sid}/{endpoint}',headers=b).status_code==404
    assert c.put(f'/api/servers/{sid}/file?path=/test.txt',headers=b,content=b'bad').status_code==404
    assert c.post(f'/api/servers/{sid}/power',headers=b,json={'signal':'start'}).status_code==404
    assert c.post('/api/servers',headers=a,json={'name':'Second','accept_eula':True}).status_code==409
    assert c.post(f'/api/servers/{sid}/files',headers=a,json={'action':'mkdir','path':'/plugins/config'}).status_code==200
    assert c.put(f'/api/servers/{sid}/file?path=/plugins/config/a.txt',headers=a,content=b'hello').status_code==200
    assert c.get(f'/api/servers/{sid}/file?path=/plugins/config/a.txt',headers=a).content==b'hello'
    assert c.post(f'/api/servers/{sid}/files',headers=a,json={'action':'rename','path':'/plugins/config','target':'/plugins/new'}).status_code==200
    assert c.get(f'/api/servers/{sid}/file?path=/plugins/new/a.txt',headers=a).content==b'hello'
    assert c.put(f'/api/servers/{sid}/file?path=/../secrets',headers=a,content=b'x').status_code==400
    assert c.post(f'/api/servers/{sid}/files',headers=a,json={'action':'delete','path':'/'}).status_code==400
    assert c.post(f'/api/servers/{sid}/files',headers=a,json={'action':'delete','path':'/plugins/new'}).status_code==200
    assert c.get(f'/api/servers/{sid}/file?path=/plugins/new/a.txt',headers=a).status_code==404

def test_expiry_reward_idempotency_and_delete(client):
    c=client; h=user(c); sid=server(c,h)
    with core.db() as db: db.execute('UPDATE servers SET expires=? WHERE id=?',(time.time()-1,sid))
    assert c.post(f'/api/servers/{sid}/power',headers=h,json={'signal':'start'}).status_code==403
    asyncio.run(main.reconcile())
    assert c.get('/api/servers',headers=h).json()[0]['status']=='suspended'
    token=c.post('/api/wallet/reward-intent',headers=h).json()['intent']
    assert c.post('/api/rewards/demo',headers=h,json={'intent':token}).status_code==200
    assert c.get('/api/wallet',headers=h).json()['balance']==10
    assert c.post('/api/shop/purchase',headers=h,json={'server_id':sid,'sku':'time_5h','idempotency_key':'renew-test-0000001'}).status_code==200
    first=c.get('/api/servers',headers=h).json()[0]
    assert first['status']=='offline' and first['expires']>time.time()
    assert c.post('/api/rewards/demo',headers=h,json={'intent':token}).status_code==200
    assert c.get('/api/servers',headers=h).json()[0]['expires']==first['expires']
    assert c.delete('/api/account',headers=h).status_code==409
    assert c.delete(f'/api/servers/{sid}',headers=h).status_code==200
    assert c.delete('/api/account',headers=h).status_code==200
    assert c.get('/api/servers',headers=h).status_code==401

def test_reward_owner_and_production_gate(client,monkeypatch):
    c=client; a=user(c); b=user(c,'two@example.com'); sid=server(c,a)
    token=c.post('/api/wallet/reward-intent',headers=a).json()['intent']
    assert c.post('/api/rewards/demo',headers=b,json={'intent':token}).status_code==400
    monkeypatch.setattr(core,'MODE','pterodactyl')
    assert c.post('/api/rewards/demo',headers=a,json={'intent':token}).status_code==404

def test_ssv_signature_tampering_and_units(monkeypatch):
    private=ec.generate_private_key(ec.SECP256R1())
    monkeypatch.setattr(rewards,'_keys',{'1':private.public_key()})
    monkeypatch.setattr(rewards,'_loaded',time.time())
    raw=urlencode({'ad_unit':'unit','custom_data':'intent','timestamp':str(int(time.time()*1000)),'transaction_id':'tx','user_id':'u'}).encode()
    sig=base64.urlsafe_b64encode(private.sign(raw,ec.ECDSA(hashes.SHA256()))).rstrip(b'=')
    query=raw+b'&signature='+sig+b'&key_id=1'
    assert asyncio.run(rewards.verify(query,{'unit'}))['transaction_id']=='tx'
    for invalid,units in [(query.replace(b'intent',b'hacked'),{'unit'}),(query,{'another-unit'}),(query+b'&user_id=attacker',{'unit'})]:
        with pytest.raises(HTTPException): asyncio.run(rewards.verify(invalid,units))

def test_failed_provision_reservation(client,monkeypatch):
    async def broken(*args): raise TimeoutError()
    monkeypatch.setattr(main.provider,'create',broken)
    h=user(client)
    assert client.post('/api/servers',headers=h,json={'name':'World','accept_eula':True}).status_code==502
    assert client.get('/api/servers',headers=h).json()[0]['status']=='provisioning_error'
    assert client.post('/api/servers',headers=h,json={'name':'World','accept_eula':True}).status_code==409

def test_logout_and_persistence(client):
    h=user(client); sid=server(client,h)
    assert client.post('/api/auth/logout',headers=h).status_code==200
    assert client.get('/api/servers',headers=h).status_code==401
    r=client.post('/api/auth/login',json={'email':'one@example.com','password':'testpassword123'})
    h={'Authorization':'Bearer '+r.json()['token']}
    assert client.get('/api/servers',headers=h).json()[0]['id']==sid

def test_file_size_and_eula(client):
    h=user(client)
    assert client.post('/api/servers',headers=h,json={'name':'World','accept_eula':False}).status_code==400
    sid=server(client,h)
    assert client.put(f'/api/servers/{sid}/file?path=/big',headers=h,content=b'x'*(core.MAX_BYTES+1)).status_code==413

def test_recreating_server_does_not_reset_free_trial(client):
    h=user(client); sid=server(client,h)
    original=client.get('/api/servers',headers=h).json()[0]['expires']
    assert client.delete(f'/api/servers/{sid}',headers=h).status_code==200
    server(client,h)
    assert client.get('/api/servers',headers=h).json()[0]['expires']==original
