import asyncio
import concurrent.futures
import json
import time
import pytest
from fastapi import HTTPException
from test_api import client, user, server
import core
import main
import shop

def earn(c,h,count=1):
    for _ in range(count):
        r=c.post('/api/wallet/reward-intent',headers=h)
        assert r.status_code==200,r.text
        assert c.post('/api/rewards/demo',headers=h,json={'intent':r.json()['intent']}).status_code==200

def buy(c,h,sid,sku='ram_512',key='purchase-key-00001'):
    return c.post('/api/shop/purchase',headers=h,json={'server_id':sid,'sku':sku,'idempotency_key':key})

def test_wallet_before_server_and_atomic_purchase(client):
    h=user(client)
    earn(client,h,4)
    assert client.get('/api/wallet',headers=h).json()['balance']==40
    sid=server(client,h)
    response=buy(client,h,sid)
    assert response.status_code==200,response.text
    assert response.json()['status']=='complete'
    assert client.get('/api/servers',headers=h).json()[0]['memory']==1536
    assert client.get('/api/wallet',headers=h).json()['balance']==0
    assert buy(client,h,sid).json()['order_id']==response.json()['order_id']
    assert buy(client,h,sid,'disk_1024').status_code==409
    assert buy(client,h,sid,key='purchase-key-00002').status_code==409

def test_reward_replay_balance_and_ownership(client):
    a=user(client);b=user(client,'second@example.com')
    intent=client.post('/api/wallet/reward-intent',headers=a).json()['intent']
    assert client.get('/api/wallet/reward-status/'+intent,headers=b).status_code==404
    assert client.post('/api/rewards/demo',headers=b,json={'intent':intent}).status_code==400
    for _ in range(3): assert client.post('/api/rewards/demo',headers=a,json={'intent':intent}).status_code==200
    wallet=client.get('/api/wallet',headers=a).json()
    assert wallet['balance']==10 and len(wallet['history'])==1

def test_ssv_amount_mismatch(client,monkeypatch):
    h=user(client);intent=client.post('/api/wallet/reward-intent',headers=h).json()
    monkeypatch.setattr(core,'MODE','pterodactyl')
    with pytest.raises(HTTPException): main.grant(intent['intent'],intent['user_id'],'tx-1','100','Monedas')
    assert client.get('/api/wallet',headers=h).json()['balance']==0
    main.grant(intent['intent'],intent['user_id'],'tx-1','10','Monedas')
    assert client.get('/api/wallet',headers=h).json()['balance']==10
    with pytest.raises(HTTPException): main.grant(intent['intent'],intent['user_id'],'tx-2','10','Monedas')

def test_pending_order_recovery(client,monkeypatch):
    h=user(client);sid=server(client,h);earn(client,h,4)
    calls=[]
    async def uncertain(s,limits): calls.append(limits);raise TimeoutError()
    monkeypatch.setattr(main.provider,'set_limits',uncertain)
    response=buy(client,h,sid)
    assert response.status_code==200 and response.json()['status']=='pending'
    assert client.get('/api/wallet',headers=h).json()['balance']==0
    assert client.delete('/api/servers/'+sid,headers=h).status_code==409
    assert buy(client,h,sid,key='another-purchase1').status_code==409
    async def success(s,limits): calls.append(limits)
    monkeypatch.setattr(main.provider,'set_limits',success)
    asyncio.run(main.reconcile())
    assert client.get('/api/servers',headers=h).json()[0]['memory']==1536
    assert all(v=={'memory':1536,'disk':2048,'cpu':100} for v in calls)
    assert client.get('/api/wallet',headers=h).json()['orders'][0]['status']=='complete'

def test_cap_limits_do_not_debit(client,monkeypatch):
    h=user(client);sid=server(client,h);earn(client,h,4)
    monkeypatch.setenv('SHOP_TOTAL_RAM_MB','1024')
    assert buy(client,h,sid).status_code==409
    assert client.get('/api/wallet',headers=h).json()['balance']==40
    monkeypatch.setenv('SHOP_TOTAL_RAM_MB','99999');monkeypatch.setenv('MAX_SERVER_RAM_MB','1024')
    assert buy(client,h,sid).status_code==409
    assert client.get('/api/wallet',headers=h).json()['balance']==40

def test_daily_limit_and_no_duplicate_intents(client,monkeypatch):
    monkeypatch.setattr(core,'DAILY_ADS',1)
    h=user(client)
    one=client.post('/api/wallet/reward-intent',headers=h).json()['intent']
    two=client.post('/api/wallet/reward-intent',headers=h).json()['intent']
    assert one==two
    client.post('/api/rewards/demo',headers=h,json={'intent':one})
    assert client.post('/api/wallet/reward-intent',headers=h).status_code==429

def test_time_cap_and_cross_user_purchase(client):
    a=user(client);b=user(client,'other@example.com');sid=server(client,a);earn(client,b,4)
    assert buy(client,b,sid).status_code==404
    earn(client,a)
    with core.db() as db: db.execute('UPDATE servers SET expires=? WHERE id=?',(time.time()+23*3600,sid))
    assert buy(client,a,sid,'time_5h').status_code==409
    assert client.get('/api/wallet',headers=a).json()['balance']==10

def test_concurrent_purchase_does_not_double_spend(client):
    h=user(client);sid=server(client,h);earn(client,h,4)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(buy,client,h,sid,'ram_512','concurrent-key-'+str(i)) for i in range(2)]
        statuses=sorted(f.result().status_code for f in futures)
    assert statuses==[200,409]
    assert client.get('/api/wallet',headers=h).json()['balance']==0
    assert client.get('/api/servers',headers=h).json()[0]['memory']==1536

def test_migration_preserves_existing_user_and_server(tmp_path,monkeypatch):
    import sqlite3
    path=str(tmp_path/'old.sqlite3');monkeypatch.setattr(core,'DB_PATH',path)
    c=sqlite3.connect(path)
    c.executescript("CREATE TABLE users(id TEXT PRIMARY KEY,email TEXT UNIQUE,password TEXT); CREATE TABLE servers(id TEXT PRIMARY KEY,user_id TEXT,name TEXT,external_id INTEGER,identifier TEXT,status TEXT,expires REAL,created REAL); INSERT INTO users VALUES('u','u@example.com','oldhash'); INSERT INTO servers VALUES('s','u','Old',NULL,'s','offline',100,10);")
    c.close();core.init_db()
    with core.db() as c:
        assert c.execute('SELECT memory FROM servers').fetchone()[0]==1024
        assert c.execute('SELECT balance FROM wallets').fetchone()[0]==0
        assert c.execute('SELECT password FROM users').fetchone()[0]=='oldhash'
