import base64
import time
from urllib.parse import parse_qs, unquote
import httpx
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from fastapi import HTTPException

KEY_URL='https://www.gstatic.com/admob/reward/verifier-keys.json'
_keys={}
_loaded=0.0

async def verify(raw: bytes, allowed_units: set[str]):
    global _keys,_loaded
    try:
        data, suffix=raw.split(b'&signature=',1)
        signature, key_tail=suffix.split(b'&key_id=',1)
        if b'&' in key_tail or b'&' in signature: raise ValueError()
        params=parse_qs(raw.decode('ascii'),keep_blank_values=True)
        if any(len(v)!=1 for v in params.values()): raise ValueError()
        key_id=key_tail.decode('ascii')
        if time.time()-_loaded>3600 or (key_id not in _keys and time.time()-_loaded>300):
            async with httpx.AsyncClient(timeout=10) as client:
                result=await client.get(KEY_URL)
                result.raise_for_status()
            _keys={str(k['keyId']):serialization.load_pem_public_key(k['pem'].encode()) for k in result.json()['keys']}
            _loaded=time.time()
        encoded=unquote(signature.decode('ascii'))
        decoded=base64.urlsafe_b64decode(encoded+'='*(-len(encoded)%4))
        _keys[key_id].verify(decoded,data,ec.ECDSA(hashes.SHA256()))
        p={k:v[0] for k,v in params.items()}
        if p['ad_unit'] not in allowed_units or abs(time.time()-int(p['timestamp'])/1000)>3600: raise ValueError()
        if not p.get('transaction_id') or not p.get('custom_data') or not p.get('user_id'): raise ValueError()
        return p
    except httpx.HTTPError:
        raise HTTPException(503,'No se pudo comprobar la firma. Reintentar.')
    except Exception:
        raise HTTPException(400,'Recompensa no válida.')
