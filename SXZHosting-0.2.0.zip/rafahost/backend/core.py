import os
import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

MODE = os.getenv('HOSTING_MODE', 'demo')
DB_PATH = os.getenv('DATABASE_PATH', 'data/rafahost.sqlite3')
MAX_BYTES = 5 * 1024 * 1024
HOURS = int(os.getenv('RENEWAL_HOURS', '5'))
MAX_HOURS = int(os.getenv('MAX_BANKED_HOURS', '24'))
CAPACITY = int(os.getenv('MAX_SERVERS', '10'))

@contextmanager
def db():
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    try:
        yield con
        con.commit()
    except BaseException:
        con.rollback()
        raise
    finally:
        con.close()

def init_db():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    with db() as c:
        c.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,trial_expires REAL);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS servers(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),name TEXT NOT NULL,
          external_id INTEGER,identifier TEXT,status TEXT NOT NULL,expires REAL NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS files(server_id TEXT REFERENCES servers(id) ON DELETE CASCADE,path TEXT,content BLOB,is_dir INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(server_id,path));
        CREATE TABLE IF NOT EXISTS logs(server_id TEXT REFERENCES servers(id) ON DELETE CASCADE,line TEXT,created REAL);
        CREATE TABLE IF NOT EXISTS intents(id TEXT PRIMARY KEY,server_id TEXT REFERENCES servers(id) ON DELETE CASCADE,user_id TEXT,expires REAL,consumed INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS rewards(transaction_id TEXT PRIMARY KEY,intent_id TEXT,created REAL);
        CREATE TABLE IF NOT EXISTS rate_limits(key TEXT PRIMARY KEY,count INTEGER,reset REAL);
        ''')
        c.executescript("""
        CREATE TABLE IF NOT EXISTS wallets(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,balance INTEGER NOT NULL DEFAULT 0 CHECK(balance>=0));
        CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT REFERENCES users(id) ON DELETE CASCADE,delta INTEGER NOT NULL,reason TEXT NOT NULL,event_id TEXT UNIQUE NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id) ON DELETE CASCADE,server_id TEXT REFERENCES servers(id) ON DELETE CASCADE,sku TEXT NOT NULL,cost INTEGER NOT NULL,status TEXT NOT NULL,desired TEXT,idempotency_key TEXT NOT NULL,created REAL NOT NULL,UNIQUE(user_id,idempotency_key));
        CREATE UNIQUE INDEX IF NOT EXISTS one_pending_order ON orders(server_id) WHERE status='pending';
        """)
        for table, additions in {
            'servers': {'memory':'INTEGER NOT NULL DEFAULT 1024','disk':'INTEGER NOT NULL DEFAULT 2048','cpu':'INTEGER NOT NULL DEFAULT 100'},
            'intents': {'reward_kind':"TEXT NOT NULL DEFAULT 'legacy_hours'",'coins':'INTEGER NOT NULL DEFAULT 0','reward_item':"TEXT NOT NULL DEFAULT 'Monedas'"}
        }.items():
            existing={row[1] for row in c.execute('PRAGMA table_info('+table+')')}
            for name, definition in additions.items():
                if name not in existing: c.execute('ALTER TABLE '+table+' ADD COLUMN '+name+' '+definition)
        c.execute('INSERT OR IGNORE INTO wallets(user_id) SELECT id FROM users')
        columns={row[1] for row in c.execute('PRAGMA table_info(users)')}
        if 'trial_expires' not in columns:
            c.execute('ALTER TABLE users ADD COLUMN trial_expires REAL')

def rate_limit(key, limit, seconds):
    from fastapi import HTTPException
    now = time.time()
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute('DELETE FROM rate_limits WHERE reset<?', (now,))
        row = c.execute('SELECT * FROM rate_limits WHERE key=?', (key,)).fetchone()
        if row and row['count'] >= limit:
            raise HTTPException(429, 'Demasiados intentos. Espera unos minutos.')
        c.execute('INSERT INTO rate_limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1', (key, now+seconds))


AD_COINS = int(os.getenv('AD_REWARD_COINS', '10'))
AD_ITEM = os.getenv('AD_REWARD_ITEM', 'Monedas')
DAILY_ADS = int(os.getenv('DAILY_REWARDED_ADS', '20'))


def base_limits():
    template=json.loads(os.getenv('PTERO_TEMPLATE_JSON','{}')) if MODE=='pterodactyl' else {}
    limits=template.get('limits',{})
    return {k:int(limits.get(k,default)) for k,default in [('memory',1024),('disk',2048),('cpu',100)]}
