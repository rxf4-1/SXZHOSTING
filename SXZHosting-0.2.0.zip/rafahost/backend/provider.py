import os
import json
import time
from pathlib import PurePosixPath
import httpx
from fastapi import HTTPException
from core import db, MAX_BYTES


def clean_path(path, allow_root=True):
    if not path.startswith('/') or '\\' in path or '\x00' in path or '..' in path.split('/'):
        raise HTTPException(400, 'Ruta no válida.')
    path = str(PurePosixPath(path))
    if len(path) > 512 or (path == '/' and not allow_root):
        raise HTTPException(400, 'Ruta no válida.')
    return path


class DemoProvider:
    async def create(self, sid, name):
        with db() as c:
            for p, content, is_dir in [('/plugins',b'',1),('/world',b'',1),('/server.properties',b'motd=Mi mundo RafaHost\nmax-players=10\nonline-mode=true\n',0),('/eula.txt',b'eula=true\n',0)]:
                c.execute('INSERT INTO files VALUES(?,?,?,?)', (sid,p,content,is_dir))
        return {'external_id': None,'identifier':sid}

    async def power(self, s, signal):
        with db() as c:
            c.execute('UPDATE servers SET status=? WHERE id=?', ('offline' if signal=='stop' else 'running',s['id']))
            c.execute('INSERT INTO logs VALUES(?,?,?)',(s['id'],f'[Demo] {signal}: operación simulada.',time.time()))

    async def suspend(self, s, suspended):
        with db() as c:
            c.execute('UPDATE servers SET status=? WHERE id=?',('suspended' if suspended else 'offline',s['id']))

    async def resources(self, s):
        return {'state':s['status'],'memory_bytes':0,'cpu_absolute':0,'disk_bytes':0,'address':'Solo demostración','limits':{k:s[k] for k in ('memory','disk','cpu')}}

    async def listing(self, s, path):
        with db() as c:
            rows=c.execute('SELECT path,is_dir,length(content) size FROM files WHERE server_id=?',(s['id'],)).fetchall()
        return [{'name':PurePosixPath(r['path']).name,'path':r['path'],'is_dir':bool(r['is_dir']),'size':r['size']} for r in rows if str(PurePosixPath(r['path']).parent)==path]

    async def read(self,s,path):
        with db() as c:
            r=c.execute('SELECT * FROM files WHERE server_id=? AND path=? AND is_dir=0',(s['id'],path)).fetchone()
        if not r: raise HTTPException(404,'Archivo no encontrado.')
        return bytes(r['content'])

    async def write(self,s,path,content):
        parent=str(PurePosixPath(path).parent)
        with db() as c:
            if parent!='/':
                if not c.execute('SELECT 1 FROM files WHERE server_id=? AND path=? AND is_dir=1',(s['id'],parent)).fetchone():
                    raise HTTPException(404,'La carpeta no existe.')
            old=c.execute('SELECT is_dir FROM files WHERE server_id=? AND path=?',(s['id'],path)).fetchone()
            if old and old['is_dir']: raise HTTPException(409,'Es una carpeta.')
            total=c.execute('SELECT COALESCE(sum(length(content)),0) FROM files WHERE server_id=?',(s['id'],)).fetchone()[0]
            if total+len(content)>20*1024*1024: raise HTTPException(413,'Límite de almacenamiento demo: 20 MB.')
            c.execute('INSERT INTO files VALUES(?,?,?,0) ON CONFLICT(server_id,path) DO UPDATE SET content=excluded.content',(s['id'],path,content))

    async def mkdir(self,s,path):
        parent=str(PurePosixPath(path).parent)
        with db() as c:
            if parent!='/' and not c.execute('SELECT 1 FROM files WHERE server_id=? AND path=? AND is_dir=1',(s['id'],parent)).fetchone():
                raise HTTPException(404,'La carpeta no existe.')
            if c.execute('SELECT 1 FROM files WHERE server_id=? AND path=?',(s['id'],path)).fetchone(): raise HTTPException(409,'El nombre ya existe.')
            c.execute('INSERT INTO files VALUES(?,?,?,1)',(s['id'],path,b''))

    async def rename(self,s,path,target):
        if target.startswith(path+'/'): raise HTTPException(400,'Destino no válido.')
        parent=str(PurePosixPath(target).parent)
        with db() as c:
            if c.execute('SELECT 1 FROM files WHERE server_id=? AND path=?',(s['id'],target)).fetchone(): raise HTTPException(409,'El destino ya existe.')
            if parent!='/' and not c.execute('SELECT 1 FROM files WHERE server_id=? AND path=? AND is_dir=1',(s['id'],parent)).fetchone(): raise HTTPException(404,'Carpeta destino no encontrada.')
            rows=c.execute('SELECT path FROM files WHERE server_id=?',(s['id'],)).fetchall()
            affected=[r['path'] for r in rows if r['path']==path or r['path'].startswith(path+'/')]
            if not affected: raise HTTPException(404,'Archivo no encontrado.')
            for old in affected: c.execute('UPDATE files SET path=? WHERE server_id=? AND path=?',(target+old[len(path):],s['id'],old))

    async def delete_file(self,s,path):
        with db() as c:
            rows=c.execute('SELECT path FROM files WHERE server_id=?',(s['id'],)).fetchall()
            for row in rows:
                if row['path']==path or row['path'].startswith(path+'/'): c.execute('DELETE FROM files WHERE server_id=? AND path=?',(s['id'],row['path']))

    async def command(self,s,command):
        with db() as c: c.execute('INSERT INTO logs VALUES(?,?,?)',(s['id'],'[Demo] > '+command,time.time()))

    async def console(self,s):
        with db() as c: rows=c.execute('SELECT line FROM logs WHERE server_id=? ORDER BY created DESC LIMIT 150',(s['id'],)).fetchall()
        return '\n'.join(r['line'] for r in reversed(rows)) or '[Demo] La consola está lista.'

    async def set_limits(self,s,limits): pass

    async def delete(self,s): pass


class PterodactylProvider:
    def __init__(self):
        self.url=os.environ['PTERO_URL'].rstrip('/')
        if not self.url.startswith('https://'): raise RuntimeError('PTERO_URL debe usar HTTPS')
        self.app_key=os.environ['PTERO_APPLICATION_KEY']
        self.client_key=os.environ['PTERO_CLIENT_KEY']
        self.owner=int(os.environ['PTERO_OWNER_ID'])
        self.template=json.loads(os.environ['PTERO_TEMPLATE_JSON'])
        if any(k in self.template for k in ('name','user','external_id')): raise RuntimeError('La plantilla no debe definir name, user o external_id')

    async def request(self,method,path,application=False,**kwargs):
        key=self.app_key if application else self.client_key
        headers={'Authorization':'Bearer '+key,'Accept':'application/json'}
        headers.update(kwargs.pop('headers',{}))
        async with httpx.AsyncClient(timeout=35,follow_redirects=False) as client:
            try: r=await client.request(method,self.url+'/api/'+('application/' if application else 'client/')+path,headers=headers,**kwargs)
            except httpx.HTTPError: raise HTTPException(502,'Pterodactyl no responde. Reintenta en un momento.')
        if r.status_code==404: raise HTTPException(404,'Recurso no encontrado en Pterodactyl.')
        if r.status_code>=300: raise HTTPException(502,f'Pterodactyl rechazó la operación ({r.status_code}).')
        return r

    def base(self,s): return 'servers/'+s['identifier']

    async def create(self,sid,name):
        payload={**self.template,'name':name,'user':self.owner,'external_id':sid,'start_on_completion':False}
        r=await self.request('POST','servers',True,json=payload)
        a=r.json()['attributes']
        return {'external_id':a['id'],'identifier':a['identifier']}

    async def power(self,s,signal): await self.request('POST',self.base(s)+'/power',json={'signal':signal})
    async def suspend(self,s,suspended): await self.request('POST',f"servers/{s['external_id']}/"+('suspend' if suspended else 'unsuspend'),True)
    async def resources(self,s):
        a=(await self.request('GET',self.base(s)+'/resources')).json()['attributes']
        detail=(await self.request('GET',self.base(s))).json()['attributes']
        allocations=detail.get('relationships',{}).get('allocations',{}).get('data',[])
        selected=next((v['attributes'] for v in allocations if v['attributes'].get('is_default')),None)
        address=f"{selected.get('ip_alias') or selected['ip']}:{selected['port']}" if selected else 'Asignando dirección'
        return {'state':a['current_state'],**a.get('resources',{}),'address':address}
    async def listing(self,s,path):
        data=(await self.request('GET',self.base(s)+'/files/list',params={'directory':path})).json()['data']
        return [{'name':a['name'],'path':str(PurePosixPath(path)/a['name']),'size':a['size'],'is_dir':not a['is_file']} for d in data if not (a:=d['attributes']).get('is_symlink',False)]
    async def read(self,s,path):
        # Bounded streaming prevents an unexpectedly large file exhausting API memory.
        async with httpx.AsyncClient(timeout=35,follow_redirects=False) as client:
            async with client.stream('GET',self.url+'/api/client/'+self.base(s)+'/files/contents',params={'file':path},headers={'Authorization':'Bearer '+self.client_key,'Accept':'text/plain'}) as r:
                if r.status_code==404: raise HTTPException(404,'Archivo no encontrado.')
                if r.status_code!=200: raise HTTPException(502,'No se pudo leer el archivo.')
                content=bytearray()
                async for chunk in r.aiter_bytes():
                    content.extend(chunk)
                    if len(content)>MAX_BYTES: raise HTTPException(413,'Archivo demasiado grande (máximo 5 MB).')
                return bytes(content)
    async def write(self,s,path,content):
        await self.request('POST',self.base(s)+'/files/write',params={'file':path},content=content,headers={'Content-Type':'application/octet-stream'})
    async def mkdir(self,s,path):
        p=PurePosixPath(path)
        await self.request('POST',self.base(s)+'/files/create-folder',json={'root':str(p.parent),'name':p.name})
    async def rename(self,s,path,target):
        await self.request('PUT',self.base(s)+'/files/rename',json={'root':'/','files':[{'from':path.lstrip('/'),'to':target.lstrip('/')}]})
    async def delete_file(self,s,path):
        await self.request('POST',self.base(s)+'/files/delete',json={'root':'/','files':[path.lstrip('/')]})
    async def command(self,s,command): await self.request('POST',self.base(s)+'/command',json={'command':command})
    async def console(self,s):
        try: return (await self.read(s,'/logs/latest.log')).decode('utf-8',errors='replace')[-30000:]
        except HTTPException as e:
            if e.status_code==404: return 'Todavía no hay un registro. Enciende el servidor para generar logs/latest.log.'
            raise
    async def delete(self,s): await self.request('DELETE',f"servers/{s['external_id']}",True)


    async def set_limits(self,s,limits):
        # Application API requires current allocation/swap/io/feature limits.
        detail=(await self.request('GET',f"servers/{s['external_id']}",True)).json()['attributes']
        current=detail['limits']
        if not all(current[k]==s[k] for k in limits) and not all(current[k]==limits[k] for k in limits):
            raise HTTPException(409,'Los límites cambiaron en el panel; el operador debe revisar la compra.')
        payload={'allocation':detail['allocation'],'memory':limits['memory'],'disk':limits['disk'],'cpu':limits['cpu'],
                 'swap':current['swap'],'io':current['io'],'feature_limits':detail['feature_limits']}
        if current.get('threads') is not None: payload['threads']=current['threads']
        await self.request('PATCH',f"servers/{s['external_id']}/build",True,json=payload)
