# SXZ Hosting · versión 0.2.0

App Flutter para administrar servidores gratuitos de Minecraft, con un backend propio y un adaptador para Pterodactyl 1.x. Incluye un panel web de prueba que utiliza la misma API.

**Estado real:** código fuente y backend de demostración verificable. No incluye una IPA firmada ni una instalación remota de Pterodactyl. El SDK Flutter no pudo prepararse en la sesión de creación por un bloqueo de revisión automática; los análisis y tests Flutter se incluyen pero quedan pendientes de ejecución. Los IDs iOS de AdMob están incorporados; faltan infraestructura real y configuración SSV en AdMob.

## Probar ahora en tu computadora

Requisitos: Python 3.12 y acceso a Internet para instalar dependencias.

```bash
cd rafahost
bash scripts/run-demo.sh
```

Abre **http://localhost:8000**. Crea una cuenta (contraseña de 10 caracteres o más), crea tu servidor y prueba iniciar/detener, archivos, consola y renovación. El modo demo simula Minecraft: no abre un puerto de juego, no ejecuta Java y no reproduce publicidad. Las cuentas, archivos y horas se conservan en SQLite entre reinicios. La sesión del panel web se mantiene solo mientras la página está abierta; inicia sesión nuevamente al recargar.

## Qué incluye

- Registro, inicio/cierre de sesión, contraseñas con scrypt y tokens revocables con caducidad.
- Un servidor por cuenta y límite global de cupos, ambos controlados por el backend.
- Iniciar, detener y reiniciar; métricas reales en modo Pterodactyl.
- Consola de Minecraft leyendo `logs/latest.log`, con comandos al servidor. Flutter consulta cada 15 segundos; el panel web tiene actualización manual. No se implementa streaming WebSocket.
- Carpetas, subida/descarga binaria, edición de texto, renombrado y borrado con confirmación. Límite: 5 MB por archivo; editor: 512 KB. Para mundos o plugins grandes, usa el panel/SFTP del operador.
- Horas iniciales por cuenta, sin reiniciarlas al eliminar y recrear el servidor.
- Renovación configurable (5 h por defecto), límite acumulable (24 h), suspensión al vencer y reactivación al renovar. Un trabajador revisa cada 20 segundos.
- AdMob móvil: consentimiento UMP, anuncio recompensado y comprobación ECDSA de callbacks en el backend. Se rechazan callbacks alterados, unidades no autorizadas y reutilización de una intención con otra transacción.
- Monedero con historial: 10 monedas por anuncio confirmado, hasta 20 anuncios al día (UTC).
- Tienda con compras por monedas: tiempo, RAM, CPU y disco. Saldo atómico, compras idempotentes y ampliaciones reintentables.
- Borrado de servidor y de cuenta. Para borrar la cuenta primero elimina su servidor.
- Docker Compose, configuración HTTPS de ejemplo, tests de backend y workflow de validación Flutter.

## Estructura

| Ruta | Contenido |
|---|---|
| `app/lib/domain` | Modelos de servidor y archivo |
| `app/lib/data` | API, repositorio y anuncios |
| `app/lib/ui` | ViewModel y pantallas Flutter |
| `backend/main.py` | API y trabajador de vencimiento |
| `backend/provider.py` | Simulador y adaptador Pterodactyl |
| `backend/rewards.py` | Verificación de recompensas |
| `backend/web` | Panel de prueba para navegador |
| `docs/DEPLOY.md` | Pasos de instalación y configuración |
| `docs/VALIDATION.md` | Evidencia de pruebas y límites |

## Preparar Flutter

Instala Flutter estable en tu máquina. El script genera las carpetas oficiales de iOS, Android y web; no se distribuyen carpetas de plataforma generadas porque el SDK no pudo ejecutarse aquí.

```bash
bash scripts/bootstrap-flutter.sh
cd app
flutter run -d chrome --dart-define=API_BASE_URL=http://localhost:8000 --web-port=8080
```

La API permite por defecto `http://localhost:8080` y `http://127.0.0.1:8080` como orígenes CORS. Para un iPhone físico usa la dirección **HTTPS** pública de tu API. No pongas claves Pterodactyl en `--dart-define` ni en la app.

```bash
flutter run --dart-define=API_BASE_URL=https://hosting.tudominio.com
```

Las compilaciones release rechazan una URL HTTP. En macOS, tras configurar firma y capacidades en Xcode:

```bash
flutter build ipa --release \
  --dart-define=API_BASE_URL=https://hosting.tudominio.com \
  --dart-define=ADMOB_LIVE=true \
  --dart-define=ADMOB_REWARDED_ID=ca-app-pub-9419517058946613/5939841867
```

El script incorpora tu App ID iOS: `ca-app-pub-9419517058946613~9936383467`. Android conserva un App ID de prueba. Los anuncios utilizan unidades de prueba salvo que pases `ADMOB_LIVE=true`. Para cambiar los App IDs:

```bash
ADMOB_IOS_APP_ID='TU_APP_ID_IOS' \
ADMOB_ANDROID_APP_ID='TU_APP_ID_ANDROID' \
python3 scripts/configure-platforms.py
```

`ADMOB_*_APP_ID` contiene `~`; el ID de unidad recompensada `ADMOB_REWARDED_ID` contiene `/`. Son valores distintos. Una app de prueba con IDs de prueba no genera ingresos.

## Antes de una distribución pública

Esta entrega es una beta de desarrollo. Todavía requiere conectar y probar una instancia real de Pterodactyl/Wings, configurar AdMob y sus callbacks, ejecutar el pipeline Flutter, probar dispositivos físicos, preparar iconos y capturas, publicar política de privacidad y soporte, completar información de App Store y firma. Los controles de registro reales usan un código de invitación para una beta privada; no hay verificación de correo ni recuperación de contraseña todavía. No se han implementado suscripciones, facturación ni copias de seguridad ni pagos con dinero real.

Los anuncios **no garantizan rentabilidad**: calcula el coste de CPU, RAM, disco y tráfico frente al ingreso efectivo por usuario. Los límites de recursos del ejemplo son una plantilla configurable, no una estimación de capacidad de tu VPS.

## Pruebas

```bash
cd backend
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock.txt
.venv/bin/pytest -q
```

`docs/VALIDATION.md` distingue las pruebas ejecutadas de las pendientes.

## Monedas y tienda

Consulta `docs/MONEDAS.md` para activar AdMob, definir precios y reservar capacidad real. Los precios incluidos son valores de prueba, no una estimación de rentabilidad.
